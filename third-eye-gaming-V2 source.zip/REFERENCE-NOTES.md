# Third Eye Gaming — reference and asset notes

Review date: 2026-10-27. User-provided websites/screenshots are reference-only; do not copy their layouts, colors, fonts, copy, or imagery.

## Design references reviewed

- Teka Teki Studios — https://www.tekatekistudios.com/ — opened successfully. Visible page and extracted content show an exploratory collage-like homepage with clickable note/poster/photo elements and About/Contact links. Do not reuse its warm amber palette, paper collage art direction, or illustrated style. Hover/motion details were not verified.
- Cofounder — https://cofounder.co/ — opened successfully. Visible page structure includes a hero with primary/secondary calls to action, case-study/social-proof and explanatory feature sections, repeated CTA, and footer. Do not reuse its pixel-art hero or visual identity. The user's promised notes were not supplied.
- Heist — https://www.heist.co/ — opened successfully. Visible page shows large typographic hero/product presentation and story/product/footer sections. Use only scale/product presentation as inspiration. Do not reuse coffee colors, serif type, or copy. Parallax/scroll motion could not be verified.
- Land-book “Board” About Us reference — the user identifies this as the first reference. Its actual image is not accessible among current session files, so no visual/storytelling specifics are inferred.
- The user-uploaded arcade/game landing reference is `/home/ubuntu/upload/pasted_file_0kZnK3_image.png`; it shows centered headline/copy, a central layered visual with supporting cards, and CTA. Use only composition as inspiration.
- The user-uploaded Heist desktop/mobile collage is `/home/ubuntu/upload/pasted_file_yoTNKY_image.png`; it is an additional homepage/footer and responsive reference. Use only structural cues, not coffee palette/serif/copy/assets.

## Selected stock imagery for the Home review

These are all real Unsplash photographs, used only as illustrative context. Captions/alt text must clearly say that they are not Third Eye Gaming products. Actual product photography remains pending.

1. Home setup image: Jeremy Rorimpandey, “Mechanical keyboard and mouse on a desk with plants.” Source: https://unsplash.com/photos/mechanical-keyboard-and-mouse-on-a-desk-with-plants-rW2KRSx2vJs . Source page identifies the Unsplash License. Local asset: `client/public/assets/home-setup-stock.webp`; managed path `/manus-storage/home-setup-stock_88509dd3.webp`; source image 3000x4500.
2. Keyboard close-up: Almas Salakhov, “A close up of a computer keyboard.” Source: https://unsplash.com/photos/a-close-up-of-a-computer-keyboard-8hTqBs8N4f0 . Source page identifies the Unsplash License. Local asset: `client/public/assets/keyboard-closeup-stock.webp`; managed path `/manus-storage/keyboard-closeup-stock_cfe08e4e.webp`; source image 3000x3996.
3. Mouse close-up: Haberdoedas, “Black computer mouse with scroll wheel resting on wood.” Source: https://unsplash.com/photos/black-computer-mouse-with-scroll-wheel-resting-on-wood-DXFWA-jLrcc . Source page identifies the Unsplash License. Local asset: `client/public/assets/mouse-closeup-stock.webp`; managed path `/manus-storage/mouse-closeup-stock_68ea509c.webp`; source image 3000x2250.

## Logo handling

The user's temporary logo file is `/home/ubuntu/upload/bold-brand-logo--horizontal-lockup-on-dark-backgro.png`. Derived transparent palette-matched variants preserve the existing mark and wordmark, recolored for Ink/Porcelain modes with the approved orange: `client/public/assets/third-eye-logo-dark.png` (`/manus-storage/third-eye-logo-dark_288a8fb3.png`) and `client/public/assets/third-eye-logo-light.png` (`/manus-storage/third-eye-logo-light_bc9f7ba7.png`). Durable platform logo URL uses the light-mode variant for contrast on a light interface: https://files.manuscdn.com/user_upload_by_module/session_file/310519664047498843/nSItQSJgWDSlOVZM.png . Do not overwrite the original supplied logo.


## User-provided UI interaction references reviewed (2026-10-28)

- Aceternity UI MacBook Scroll: https://ui.aceternity.com/components/macbook-scroll — use its sticky, scroll-driven zoom/reveal behavior for a stock keyboard-to-keycap detail sequence; do not copy its visual styling.
- Aceternity UI Text Hover Effect: https://ui.aceternity.com/components/text-hover-effect — use the interaction principle for the landing-page wordmark while keeping the logo readable and accessible.
- Aceternity UI Comet Card: https://ui.aceternity.com/components/comet-card — use its pointer-responsive perspective treatment for keycap product cards, not its code/styling wholesale.
- Aceternity UI Mega Navbar: https://ui.aceternity.com/blocks/navbars/navbar-mega — use the grouped/disclosure navigation behavior for the five categories and pages, adapted to this brand.

## Licensed 3D references reviewed

- Mouse fit-reference: `Computer mouse` by zhe_kan, Sketchfab model UID `6e7940d9e2144efeae3468a906f27e07`, https://sketchfab.com/3d-models/computer-mouse-6e7940d9e2144efeae3468a906f27e07 . The page describes it as modeled after the Logitech G PRO X SUPERLIGHT and displays Creative Commons Attribution 4.0 (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/ . A public Sketchfab embed is available. Attempting the download button opened a login dialog, so use the creator's hosted iframe rather than scraping/downloading the asset. Attribute the creator, source and license visibly.
- Keyboard reference: `Custom - Mechanical Keyboard` by the Sketchfab account `ibrahimtaha.fbx`, displayed creator label `unknown.fbx`, model UID `90d61eec0c484332ab562c5f4eda6f52`, https://sketchfab.com/3d-models/custom-mechanical-keyboard-90d61eec0c484332ab562c5f4eda6f52 . The page identifies a 60% custom mechanical keyboard and CC BY 4.0; an embed is available. The page also carries a NoAI restriction; the model will only be embedded as user-facing media and will not be used in AI datasets, training or generation. Attribute creator, source and license visibly.
- Both models are illustrative reference models only, not Third Eye Gaming products or final product CAD. Keep meaningful text/photo fallback content visible when the external model viewer is unavailable.
- During source inspection, Sketchfab's viewer area reported “Something went wrong with the 3D viewer. Connection error.” This is evidence of a sandbox viewer/network limitation, not proof of a local React rendering exception. Lazy-load the embedded viewer and provide a direct source-page fallback link.

## Superlight reference dimensions and retailer destinations

- The B&H Photo Video comparison of the original PRO X SUPERLIGHT and PRO X SUPERLIGHT 2 lists `125 × 63.5 × 40 mm` for both models. Source: https://www.bhphotovideo.com/c/compare/Logitech+G_Pro+X+Superlight+2_vs_Logitech+G_PRO+X+SUPERLIGHT/BHitems/1785646-REG_1609024-REG . Logitech's support article was opened but rendered blank in this browser. Use the dimensions only as the requested fit-reference; state that exact mouse revision/fit must be validated before manufacturing.
- User-authorized general retailer homepages, fetched and confirmed as accessory stores: Meckeys — https://meckeys.com/ ; Genesis PC — https://www.genesispc.in/ . The user explicitly said product-specific purchase links are not required and homepage links are acceptable. Label these as retailer homepages, not live listings for Third Eye Gaming products.
