import { describe, expect, it, vi } from "vitest";
import {
  rateLimit,
  sameOriginApi,
  securityHeaders,
  safeErrorHandler,
} from "./_core/security";
import { appRouter } from "./routers";
import { normalizeCart } from "../client/src/contexts/CartContext";

function response() {
  const res = { setHeader: vi.fn(), status: vi.fn(), json: vi.fn() };
  res.status.mockReturnValue(res);
  return res;
}

describe("request boundaries", () => {
  it("rejects cross-site writes and accepts same-origin writes", () => {
    const next = vi.fn();
    const res = response();
    const req = {
      method: "POST",
      protocol: "http",
      get: () => "localhost:3000",
      headers: { origin: "https://attacker.example" },
    };
    sameOriginApi(req as never, res as never, next);
    expect(res.status).toHaveBeenCalledWith(403);
    expect(next).not.toHaveBeenCalled();
    req.headers.origin = "http://localhost:3000";
    sameOriginApi(req as never, res as never, next);
    expect(next).toHaveBeenCalledOnce();
  });
  it("does not permit spoofed forwarding headers to bypass the limiter", () => {
    const limit = rateLimit(2);
    const res = response();
    const next = vi.fn();
    for (let i = 0; i < 3; i++)
      limit(
        {
          socket: { remoteAddress: "127.0.0.1" },
          headers: { "x-forwarded-for": `spoof-${i}` },
        } as never,
        res as never,
        next
      );
    expect(next).toHaveBeenCalledTimes(2);
    expect(res.status).toHaveBeenCalledWith(429);
    expect(res.setHeader).toHaveBeenCalledWith(
      "Retry-After",
      expect.any(String)
    );
  });
  it("restricts production scripts and preserves the approved embed origin", () => {
    const res = response();
    securityHeaders(true, ["'sha256-test'"])(
      {} as never,
      res as never,
      vi.fn()
    );
    const csp = res.setHeader.mock.calls.find(
      ([name]) => name === "Content-Security-Policy"
    )?.[1];
    expect(csp).toContain("script-src 'self' 'sha256-test'");
    expect(csp).toContain("frame-src https://sketchfab.com");
    expect(csp).not.toContain("unsafe-eval");
  });
  it("does not return private error messages or stack traces", () => {
    const res = response();
    safeErrorHandler(
      new Error("private connection details"),
      {} as never,
      res as never,
      vi.fn()
    );
    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ error: "Internal server error" });
  });
  it("denies anonymous and regular users the owner notification endpoint", async () => {
    for (const user of [null, { role: "user" }]) {
      const caller = appRouter.createCaller({
        user,
        req: {},
        res: {},
      } as never);
      await expect(
        caller.system.notifyOwner({ title: "test", content: "test" })
      ).rejects.toMatchObject({ code: "FORBIDDEN" });
    }
  });
});

describe("persisted preview cart", () => {
  it("merges duplicate lines, caps quantity and rejects tampered data", () => {
    expect(
      normalizeCart([
        { productId: "keycap-01", quantity: 2 },
        { productId: "keycap-01", quantity: 100 },
        { productId: "unknown", quantity: 1 },
        { productId: "artisan-01", quantity: -1 },
        { productId: "artisan-01", quantity: 1.5 },
        null,
        { productId: "artisan-01", quantity: Infinity },
      ])
    ).toEqual([{ productId: "keycap-01", quantity: 99 }]);
    expect(normalizeCart({})).toEqual([]);
  });
});
