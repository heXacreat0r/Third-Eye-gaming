import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import path from "node:path";
import {
  rateLimit,
  safeErrorHandler,
  sameOriginApi,
  securityHeaders,
} from "./security";

process.env.NODE_ENV ??= process.argv.includes("--development")
  ? "development"
  : "production";

async function startServer() {
  const app = express();
  const server = createServer(app);
  const production = process.env.NODE_ENV === "production";
  const scriptHashes = production
    ? Array.from(
        readFileSync(
          path.join(import.meta.dirname, "public/index.html"),
          "utf8"
        ).matchAll(/<script>([\s\S]*?)<\/script>/g),
        match =>
          `'sha256-${createHash("sha256").update(match[1]).digest("base64")}'`
      )
    : [];
  if (
    process.env.APP_ORIGIN &&
    !/^https?:\/\/[^/]+$/.test(process.env.APP_ORIGIN)
  )
    throw new Error("APP_ORIGIN must be an origin without a trailing slash");
  app.disable("x-powered-by");
  app.use(securityHeaders(production, scriptHashes));
  app.use("/api", rateLimit(180), sameOriginApi);
  app.use(express.json({ limit: "64kb", inflate: false }));
  app.use(
    express.urlencoded({
      limit: "16kb",
      extended: false,
      parameterLimit: 30,
      inflate: false,
    })
  );
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res
      .set("Cache-Control", "no-store")
      .type("application/javascript")
      .send(publicPlatformScript());
  });
  app.use("/api/oauth", rateLimit(20));
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "API route not found" });
  });
  app.use("/__manus__", (_req, res) => {
    res.sendStatus(404);
  });
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  app.use(safeErrorHandler);

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535)
    throw new Error("Invalid PORT");
  server.on("error", error => {
    console.error("Server failed:", error.message);
    process.exit(1);
  });
  server.listen(port, "0.0.0.0", () =>
    console.log(`Server listening on port ${port}`)
  );
}

startServer().catch(error => {
  console.error(error);
  process.exit(1);
});
