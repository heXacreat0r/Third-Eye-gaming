import type { ErrorRequestHandler, RequestHandler } from "express";

// The storefront needs local assets, Google Fonts and opt-in Sketchfab frames.
// Inline styles support Framer Motion; scripts are restricted to self and the
// hash of the small theme bootstrap (computed from the built HTML at startup).
export function securityHeaders(
  production: boolean,
  scriptHashes: string[] = []
): RequestHandler {
  return (_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader(
      "Permissions-Policy",
      "camera=(), microphone=(), geolocation=()"
    );
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    if (production)
      res.setHeader(
        "Content-Security-Policy",
        [
          "default-src 'self'",
          `script-src 'self' ${scriptHashes.join(" ")}`,
          "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
          "font-src 'self' https://fonts.gstatic.com",
          "img-src 'self' data: https://files.manuscdn.com",
          "connect-src 'self'",
          "frame-src https://sketchfab.com",
          "frame-ancestors 'self'",
          "object-src 'none'",
          "base-uri 'self'",
          "form-action 'self'",
        ].join("; ")
      );
    next();
  };
}

// No cross-origin API consumers exist in this app. Do not trust forwarded host
// headers. APP_ORIGIN supplies the real public origin behind a reverse proxy.
export const sameOriginApi: RequestHandler = (req, res, next) => {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const expectedOrigin =
    process.env.APP_ORIGIN || `${req.protocol}://${req.get("host")}`;
  if (
    req.headers["sec-fetch-site"] === "cross-site" ||
    (req.headers.origin && req.headers.origin !== expectedOrigin)
  ) {
    res.status(403).json({ error: "Cross-origin request rejected" });
    return;
  }
  next();
};

// Per-process protection, intentionally keyed by socket address rather than
// spoofable X-Forwarded-For. Distributed limits belong at the hosting edge.
export function rateLimit(max: number, windowMs = 60_000): RequestHandler {
  const clients = new Map<string, { count: number; expires: number }>();
  return (req, res, next) => {
    const now = Date.now();
    for (const [key, value] of clients)
      if (value.expires <= now) clients.delete(key);
    const key = req.socket.remoteAddress || "unknown";
    const bucket = clients.get(key) ?? { count: 0, expires: now + windowMs };
    if (!clients.has(key) && clients.size >= 10_000) {
      res.status(503).json({ error: "Service busy" });
      return;
    }
    clients.set(key, bucket);
    if (++bucket.count > max) {
      res.setHeader(
        "Retry-After",
        String(Math.max(1, Math.ceil((bucket.expires - now) / 1000)))
      );
      res.status(429).json({ error: "Too many requests" });
      return;
    }
    next();
  };
}

export const safeErrorHandler: ErrorRequestHandler = (
  error,
  _req,
  res,
  _next
) => {
  const status =
    error?.type === "entity.too.large"
      ? 413
      : error instanceof SyntaxError
        ? 400
        : 500;
  res
    .status(status)
    .json({
      error:
        status === 413
          ? "Request too large"
          : status === 400
            ? "Invalid request"
            : "Internal server error",
    });
};
