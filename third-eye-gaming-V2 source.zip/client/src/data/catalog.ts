import { categories, stockAssets, type Category, type CategoryId } from "./homeContent";

export { categories };
export type { Category, CategoryId };

export type ProductVisual = "keyboard-photo" | "mouse-photo" | "keychain-abstract";

export type Product = {
  id: string;
  categoryId: CategoryId;
  name: string;
  price: number;
  description: string;
  visual: ProductVisual;
  featured: boolean;
  detailModel?: "keyboard" | "mouse";
};

export const categoryPaths: Record<CategoryId, string> = {
  keycaps: "/categories/keycaps",
  "artisan-keycaps": "/categories/artisan-keycaps",
  "keycap-keychains": "/categories/keycap-keychains",
  "mouse-grips": "/categories/mouse-grips",
  "mouse-skates": "/categories/mouse-skates",
};

export const retailers = [
  { name: "Meckeys", href: "https://meckeys.com/" },
  { name: "Genesis PC", href: "https://www.genesispc.in/" },
] as const;

// These names and prices are owner-authorized sample values for the investor preview only.
// They are not confirmed launch SKUs, final prices, or live retailer listings.
export const products: Product[] = [
  { id: "keycap-01", categoryId: "keycaps", name: "Keycap 1", price: 1299, description: "A considered touchpoint for the mechanical keyboard already on your desk.", visual: "keyboard-photo", featured: true, detailModel: "keyboard" },
  { id: "keycap-02", categoryId: "keycaps", name: "Keycap 2", price: 1499, description: "A second sample direction for a setup shaped around your own taste.", visual: "keyboard-photo", featured: false, detailModel: "keyboard" },
  { id: "artisan-01", categoryId: "artisan-keycaps", name: "Artisan 1", price: 699, description: "One expressive accent for the key you reach for most.", visual: "keyboard-photo", featured: true, detailModel: "keyboard" },
  { id: "artisan-02", categoryId: "artisan-keycaps", name: "Artisan 2", price: 799, description: "A small sculptural detail in a keyboard-first setup.", visual: "keyboard-photo", featured: false, detailModel: "keyboard" },
  { id: "keychain-01", categoryId: "keycap-keychains", name: "Keycap Keychain 1", price: 399, description: "A keyboard-inspired detail to take beyond the desk.", visual: "keychain-abstract", featured: true },
  { id: "keychain-02", categoryId: "keycap-keychains", name: "Keycap Keychain 2", price: 499, description: "A second sample take on a familiar key, made portable.", visual: "keychain-abstract", featured: false },
  { id: "grip-01", categoryId: "mouse-grips", name: "Grip Set 1", price: 599, description: "A sample tactile detail shown with the Superlight fit-reference mouse.", visual: "mouse-photo", featured: true, detailModel: "mouse" },
  { id: "grip-02", categoryId: "mouse-grips", name: "Grip Set 2", price: 699, description: "An alternate sample direction for a mouse-accessory setup.", visual: "mouse-photo", featured: false, detailModel: "mouse" },
  { id: "skates-01", categoryId: "mouse-skates", name: "Skate Set 1", price: 499, description: "A sample mouse-movement accessory shown beside the Superlight reference model.", visual: "mouse-photo", featured: true, detailModel: "mouse" },
  { id: "skates-02", categoryId: "mouse-skates", name: "Skate Set 2", price: 599, description: "A second illustrative option for the mouse-skates category.", visual: "mouse-photo", featured: false, detailModel: "mouse" },
];

export const superlightReference = {
  name: "Logitech G PRO X SUPERLIGHT",
  dimensions: "125 × 63.5 × 40 mm",
  source: "https://www.bhphotovideo.com/c/compare/Logitech+G_Pro+X+Superlight+2_vs_Logitech+G_PRO+X+SUPERLIGHT/BHitems/1785646-REG_1609024-REG",
  note: "Reference dimensions only; verify the exact hardware revision and accessory fit before manufacturing.",
};

export const modelReferences = {
  keyboard: {
    uid: "90d61eec0c484332ab562c5f4eda6f52",
    title: "Custom - Mechanical Keyboard",
    creator: "unknown.fbx / ibrahimtaha.fbx",
    source: "https://sketchfab.com/3d-models/custom-mechanical-keyboard-90d61eec0c484332ab562c5f4eda6f52",
    license: "CC BY 4.0",
    licenseUrl: "https://creativecommons.org/licenses/by/4.0/",
  },
  mouse: {
    uid: "6e7940d9e2144efeae3468a906f27e07",
    title: "Computer mouse (modeled after Logitech G PRO X SUPERLIGHT)",
    creator: "zhe_kan",
    source: "https://sketchfab.com/3d-models/computer-mouse-6e7940d9e2144efeae3468a906f27e07",
    license: "CC BY 4.0",
    licenseUrl: "https://creativecommons.org/licenses/by/4.0/",
  },
} as const;

export function getCategory(categoryId: CategoryId): Category {
  return categories.find((category) => category.id === categoryId)!;
}

export function getProductsForCategory(categoryId: CategoryId): Product[] {
  return products.filter((product) => product.categoryId === categoryId);
}

export function getProduct(productId: string): Product | undefined {
  return products.find((product) => product.id === productId);
}

export function getProductPath(product: Product): string {
  return `/products/${product.id}`;
}

export function getVisualAsset(visual: ProductVisual) {
  if (visual === "keyboard-photo") return stockAssets.keyboard;
  if (visual === "mouse-photo") return stockAssets.mouse;
  return null;
}

export function formatINR(value: number): string {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}
