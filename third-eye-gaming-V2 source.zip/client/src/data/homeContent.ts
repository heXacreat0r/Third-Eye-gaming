export const pageCopy = {
  title: "Third Eye Gaming — Accessories for Mouse & Keyboard Setups",
  description:
    "Thoughtful gaming accessories for mouse-and-keyboard setups. Explore keycaps, artisan keycaps, keycap keychains, mouse grips and mouse skates.",
  heroEyebrow: "THIRD EYE GAMING / ACCESSORIES FOR YOUR SETUP",
  heroTitle: "The details that make a setup yours.",
  visionTitle: "Make every setup feel like your own.",
  visionDescription:
    "Our vision is to bring thoughtful design, personal expression and everyday comfort to the details you touch — so your desk feels as individual as the way you play.",
  heroDescription:
    "A specialist accessories brand for mouse-and-keyboard setups, focused on considered design and comfort in the small details.",
  featuredTitle: "Featured accessories",
  featuredDescription:
    "A considered first look across keycaps, artisan keycaps, keycap keychains, mouse grips and mouse skates. Names and prices in this preview are illustrative.",
  categoriesTitle: "Small details. Your kind of setup.",
  flowTitle: "A closer look, in motion.",
  flowDescription:
    "Start with the whole setup. Scroll closer to the small details that shape how it feels.",
  brandTitle: "We make accessories, not another keyboard or mouse.",
  brandDescription:
    "Third Eye Gaming is a specialist gaming-accessories brand for mouse-and-keyboard setups. The point of view is quiet luxury in the details: thoughtful design, comfort, and the small things that matter.",
  closingTitle: "The setup is yours. Make the details count.",
} as const;

export type CategoryId =
  | "keycaps"
  | "artisan-keycaps"
  | "keycap-keychains"
  | "mouse-grips"
  | "mouse-skates";

export type Category = {
  id: CategoryId;
  name: string;
  number: string;
  eyebrow: string;
  description: string;
  accent: string;
  foreground: string;
};

export const categories: Category[] = [
  {
    id: "keycaps",
    name: "Keycaps",
    number: "01",
    eyebrow: "KEYBOARD / DETAILS",
    description: "A new touchpoint for the keyboard already on your desk.",
    accent: "#E45C32",
    foreground: "#171615",
  },
  {
    id: "artisan-keycaps",
    name: "Artisan keycaps",
    number: "02",
    eyebrow: "KEYBOARD / CHARACTER",
    description: "Single-key details with room for personality.",
    accent: "#964633",
    foreground: "#F2EEE7",
  },
  {
    id: "keycap-keychains",
    name: "Keycap keychains",
    number: "03",
    eyebrow: "BEYOND THE DESK",
    description: "Keyboard-inspired details to carry with you.",
    accent: "#87572D",
    foreground: "#F2EEE7",
  },
  {
    id: "mouse-grips",
    name: "Mouse grips",
    number: "04",
    eyebrow: "MOUSE / FEEL",
    description: "A tactile detail for how your mouse meets your hand.",
    accent: "#58665A",
    foreground: "#F2EEE7",
  },
  {
    id: "mouse-skates",
    name: "Mouse skates",
    number: "05",
    eyebrow: "MOUSE / MOVEMENT",
    description: "Small details for the way a mouse moves.",
    accent: "#586467",
    foreground: "#F2EEE7",
  },
];

export const stockAssets = {
  setup: {
    src: "/assets/home-setup-stock.webp",
    alt: "Illustrative stock photograph of a mechanical keyboard and mouse on a desk with plants; not a Third Eye Gaming product.",
    credit: "Jeremy Rorimpandey / Unsplash",
    source:
      "https://unsplash.com/photos/mechanical-keyboard-and-mouse-on-a-desk-with-plants-rW2KRSx2vJs",
    dimensions:
      "3000 × 4500 px source; displayed as a cropped 4:5 editorial image",
  },
  keyboard: {
    src: "/assets/keyboard-closeup-stock.webp",
    alt: "Illustrative stock close-up of a black, white and red computer keyboard; not a Third Eye Gaming product.",
    credit: "Almas Salakhov / Unsplash",
    source:
      "https://unsplash.com/photos/a-close-up-of-a-computer-keyboard-8hTqBs8N4f0",
    dimensions:
      "3000 × 3996 px source; displayed as a cropped 3:2 feature image",
  },
  mouse: {
    src: "/assets/mouse-closeup-stock.webp",
    alt: "Illustrative stock close-up of a black computer mouse on a wooden desk; not a Third Eye Gaming product.",
    credit: "Haberdoedas / Unsplash",
    source:
      "https://unsplash.com/photos/black-computer-mouse-with-scroll-wheel-resting-on-wood-DXFWA-jLrcc",
    dimensions:
      "3000 × 2250 px source; displayed as a cropped 4:3 feature image",
  },
} as const;
