import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

type Theme = "light" | "dark";

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
  switchable: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: Theme;
  switchable?: boolean;
}

function getStoredTheme(): Theme | null {
  try {
    const stored = localStorage.getItem("third-eye-theme");
    return stored === "light" || stored === "dark" ? stored : null;
  } catch {
    return null;
  }
}

function getSystemTheme(): Theme {
  return typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
}

export function ThemeProvider({
  children,
  defaultTheme = "light",
  switchable = true,
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(() => getStoredTheme() ?? getSystemTheme() ?? defaultTheme);
  const [hasManualChoice, setHasManualChoice] = useState(() => getStoredTheme() !== null);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = theme;
    root.classList.toggle("dark", theme === "dark");
    root.style.colorScheme = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute(
      "content",
      theme === "dark" ? "#171615" : "#F2EEE7"
    );
    if (hasManualChoice) {
      try {
        localStorage.setItem("third-eye-theme", theme);
      } catch {
        // Continue with the in-memory theme if storage is unavailable.
      }
    }
  }, [theme, hasManualChoice]);

  useEffect(() => {
    if (hasManualChoice || !switchable) return;
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = (event: MediaQueryListEvent) => setTheme(event.matches ? "dark" : "light");
    media.addEventListener?.("change", onChange);
    return () => media.removeEventListener?.("change", onChange);
  }, [hasManualChoice, switchable]);

  const toggleTheme = useCallback(() => {
    if (!switchable) return;
    setTheme((current) => {
      const next = current === "dark" ? "light" : "dark";
      try {
        localStorage.setItem("third-eye-theme", next);
      } catch {
        // The preference still applies for this visit.
      }
      return next;
    });
    setHasManualChoice(true);
  }, [switchable]);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, switchable }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within ThemeProvider");
  return context;
}
