import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { getProduct } from "@/data/catalog";

export type CartLine = { productId: string; quantity: number };
type CartContextValue = {
  items: CartLine[];
  count: number;
  subtotal: number;
  open: boolean;
  setOpen: (open: boolean) => void;
  add: (productId: string) => void;
  changeQuantity: (productId: string, quantity: number) => void;
  remove: (productId: string) => void;
};

const STORAGE_KEY = "third-eye-preview-cart-v1";
export const MAX_CART_QUANTITY = 99;
const CartContext = createContext<CartContextValue | null>(null);

export function normalizeCart(raw: unknown): CartLine[] {
  if (!Array.isArray(raw)) return [];
  const quantities = new Map<string, number>();
  for (const item of raw.slice(0, 1000)) {
    if (
      !item ||
      typeof item !== "object" ||
      !getProduct(item.productId) ||
      !Number.isSafeInteger(item.quantity) ||
      item.quantity <= 0
    )
      continue;
    quantities.set(
      item.productId,
      Math.min(
        MAX_CART_QUANTITY,
        (quantities.get(item.productId) ?? 0) + item.quantity
      )
    );
  }
  return Array.from(quantities, ([productId, quantity]) => ({
    productId,
    quantity,
  }));
}

function readCart(): CartLine[] {
  try {
    const raw: unknown = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
    return normalizeCart(raw);
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartLine[]>([]);
  const [open, setOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setItems(readCart());
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // Keep the cart usable for this visit if storage is unavailable.
    }
  }, [items, loaded]);

  const add = useCallback((productId: string) => {
    if (!getProduct(productId)) return;
    setItems(current => {
      const existing = current.find(line => line.productId === productId);
      return existing
        ? current.map(line =>
            line.productId === productId
              ? {
                  ...line,
                  quantity: Math.min(MAX_CART_QUANTITY, line.quantity + 1),
                }
              : line
          )
        : [...current, { productId, quantity: 1 }];
    });
    setOpen(true);
  }, []);

  const changeQuantity = useCallback((productId: string, quantity: number) => {
    if (!Number.isSafeInteger(quantity)) return;
    quantity = Math.min(MAX_CART_QUANTITY, quantity);
    setItems(current =>
      quantity <= 0
        ? current.filter(line => line.productId !== productId)
        : current.map(line =>
            line.productId === productId ? { ...line, quantity } : line
          )
    );
  }, []);

  const remove = useCallback((productId: string) => {
    setItems(current => current.filter(line => line.productId !== productId));
  }, []);

  const value = useMemo(() => {
    const count = items.reduce((sum, line) => sum + line.quantity, 0);
    const subtotal = items.reduce(
      (sum, line) =>
        sum + (getProduct(line.productId)?.price ?? 0) * line.quantity,
      0
    );
    return {
      items,
      count,
      subtotal,
      open,
      setOpen,
      add,
      changeQuantity,
      remove,
    };
  }, [items, open, add, changeQuantity, remove]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const value = useContext(CartContext);
  if (!value) throw new Error("useCart must be used within CartProvider");
  return value;
}
