import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import { PageMeta } from "@/components/brand/PageMeta";
import { ProductCard } from "@/components/brand/ProductCard";
import { Reveal } from "@/components/brand/Reveal";
import { SiteLayout } from "@/components/brand/SiteLayout";
import { SketchfabViewer } from "@/components/brand/SketchfabViewer";
import { getCategory, getProductsForCategory, type CategoryId } from "@/data/catalog";

export default function CategoryPage({ categoryId }: { categoryId: CategoryId }) {
  const category = getCategory(categoryId);
  const items = getProductsForCategory(categoryId);
  const title = `${category.name} | Third Eye Gaming`;
  const description = `${category.description} Browse sample ${category.name.toLowerCase()} preview items from Third Eye Gaming.`;
  const modelKind = categoryId === "keycaps" || categoryId === "artisan-keycaps" ? "keyboard" : categoryId === "mouse-grips" || categoryId === "mouse-skates" ? "mouse" : null;

  return <SiteLayout>
    <PageMeta title={title} description={description} />
    <main id="main-content" className="page-main category-page">
      <section className="category-page-hero page-width" style={{ "--category-accent": category.accent, "--category-foreground": category.foreground } as React.CSSProperties}>
        <Link href="/shop" className="back-link"><ArrowLeft size={14} aria-hidden="true" /> All categories</Link>
        <div className="category-page-title"><p className="eyebrow"><span className="eyebrow-mark" aria-hidden="true" />{category.number} / {category.eyebrow}</p><h1>{category.name}<span>.</span></h1><p>{category.description}</p></div>
        <div className="category-page-mark" aria-hidden="true"><span>{category.number}</span><i /><i /><i /><i /><b /></div>
      </section>
      <section className="category-products page-width" aria-labelledby="category-items-title">
        <div className="section-heading section-heading-split"><div><p className="eyebrow">SAMPLE COLLECTION</p><h2 id="category-items-title">Featured in {category.name.toLowerCase()}.</h2></div><p className="section-intro">Names and INR prices here are illustrative preview data. Product materials, compatibility and actual photography are pending.</p></div>
        <div className="product-grid">{items.map((product) => <Reveal key={product.id}><ProductCard product={product} /></Reveal>)}</div>
      </section>
      {modelKind && <section className="category-model-section page-width" aria-labelledby="category-model-title"><div className="category-model-copy"><p className="eyebrow">REFERENCE VIEWER / 360°</p><h2 id="category-model-title">Turn the reference around.</h2><p>{modelKind === "mouse" ? "Explore the Superlight-shaped mouse reference from every angle. This is a third-party model, not a Third Eye Gaming product; fitment is not verified." : "Rotate the keyboard reference and inspect the form. This is a generic model, not a Third Eye Gaming keycap set or final product CAD."}</p><Link className="button-text" href={items[0] ? `/products/${items[0].id}` : "/shop"}>View a featured sample <ArrowUpRight size={14} aria-hidden="true" /></Link></div><SketchfabViewer kind={modelKind} /></section>}
      {!modelKind && <section className="category-note page-width"><span className="category-note-mark" aria-hidden="true">03</span><div><p className="eyebrow">A SMALL DETAIL, OFF THE DESK</p><h2>Keyboard-inspired, made portable.</h2><p>The graphic is an abstract category marker, not a product rendering. Final product photography and specifications will replace this illustrative preview.</p></div></section>}
      <p className="page-disclaimer page-width">Preview catalogue only · sample names and prices · no product-specific retailer listing or payment checkout.</p>
    </main>
  </SiteLayout>;
}
