import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import { PageMeta } from "@/components/brand/PageMeta";
import { SiteLayout } from "@/components/brand/SiteLayout";
import { categories } from "@/data/homeContent";
import { categoryPaths, getProductsForCategory } from "@/data/catalog";
import { Reveal } from "@/components/brand/Reveal";

export default function ShopPage() {
  return <SiteLayout>
    <PageMeta title="Shop accessories | Third Eye Gaming" description="Browse keycaps, artisan keycaps, keycap keychains, mouse grips and mouse skates from Third Eye Gaming." />
    <main id="main-content" className="page-main">
      <section className="page-hero page-width"><p className="eyebrow"><span className="eyebrow-mark" aria-hidden="true" />SHOP / 01—05</p><h1>Accessories for the setup you already own.</h1><p>Explore five touchpoints for mouse-and-keyboard setups. Sample names and INR prices are illustrative preview data, not final offers.</p></section>
      <section className="shop-categories page-width" aria-label="Accessory categories">
        {categories.map((category, index) => <Reveal key={category.id} delay={index * 0.04}><Link className="shop-category-card" href={categoryPaths[category.id]} style={{ "--category-accent": category.accent, "--category-foreground": category.foreground } as React.CSSProperties}>
          <span className="shop-category-index">{category.number} / 05</span><span className="shop-category-art" aria-hidden="true"><i /><i /><i /><i /><b /></span><span className="shop-category-copy"><span className="eyebrow">{category.eyebrow}</span><strong>{category.name}</strong><small>{category.description}</small><span className="shop-category-count">{getProductsForCategory(category.id).length} sample items <ArrowUpRight size={14} aria-hidden="true" /></span></span>
        </Link></Reveal>)}
      </section>
      <p className="page-disclaimer page-width">Stock imagery and licensed 3D references on these pages are illustrative only and do not depict finalized Third Eye Gaming products.</p>
    </main>
  </SiteLayout>;
}
