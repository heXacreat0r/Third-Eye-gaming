import { ExternalLink } from "lucide-react";
import { PageMeta } from "@/components/brand/PageMeta";
import { SiteLayout } from "@/components/brand/SiteLayout";
import { retailers } from "@/data/catalog";

const supportItems = [
  { question: "Where will Third Eye Gaming ship?", answer: "The current plan is to ship across India. Final fulfillment details will be confirmed before orders open." },
  { question: "When are shipping charges shown?", answer: "Shipping costs are expected to be added at checkout. The retailer homepages below are general destinations, not product-specific listings; each retailer controls its own checkout and shipping terms." },
  { question: "What is the return period?", answer: "The current stated return period is one month. Eligibility, process, exclusions and refund timing have not been supplied yet and must be confirmed before final policy publication." },
  { question: "Where can I browse accessories?", answer: "Meckeys and Genesis PC are provided as general accessory retailer homepages. Third Eye Gaming product-specific listings are not yet available at those destinations." },
];

export default function SupportPage() {
  return <SiteLayout>
    <PageMeta title="Support & policies | Third Eye Gaming" description="Find current shipping, return-period and retailer-handoff information for Third Eye Gaming. Final policy terms and support contact details are pending." />
    <main id="main-content" className="page-main support-page">
      <section className="page-hero page-width"><p className="eyebrow"><span className="eyebrow-mark" aria-hidden="true" />SUPPORT / INFORMATION</p><h1>Clear answers, as they become final.</h1><p>Current policy facts are shown below. Full conditions and the support channel will be added once confirmed.</p></section>
      <section className="support-faq page-width" aria-label="Support and policy questions">{supportItems.map((item, index) => <details className="support-item" key={item.question} open={index === 0}><summary><span className="support-index">0{index + 1}</span><strong>{item.question}</strong><span aria-hidden="true">+</span></summary><p>{item.answer}</p></details>)}</section>
      <section className="support-destinations page-width"><div><p className="eyebrow">RETAILER HOME PAGES</p><h2>Browse accessory retailers.</h2><p>These are general homepages, not listings for Third Eye Gaming products.</p></div><div className="retailer-link-list">{retailers.map((retailer) => <a key={retailer.name} href={retailer.href} target="_blank" rel="noreferrer">{retailer.name}<ExternalLink size={15} aria-hidden="true" /></a>)}</div></section>
      <section className="support-contact page-width"><p className="eyebrow">CONTACT / NOT YET PROVIDED</p><h2>Support contact details have not been supplied.</h2><p>No email address, phone number or social account is displayed until the owner provides one.</p></section>
      <p className="page-disclaimer page-width">Policy summary is a draft based only on the facts provided: India-wide shipping, shipping charges added at checkout, and a one-month return period. Final terms and partner-retailer applicability require confirmation.</p>
    </main>
  </SiteLayout>;
}
