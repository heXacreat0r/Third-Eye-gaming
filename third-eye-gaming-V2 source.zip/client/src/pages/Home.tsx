import { useRef } from "react";
import {
  ArrowDown,
  ArrowDownRight,
  ArrowUpRight,
  ChevronRight,
} from "lucide-react";
import { Link } from "wouter";
import {
  motion,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import { PageMeta } from "@/components/brand/PageMeta";
import { BrandVisionBanner } from "@/components/brand/BrandVisionBanner";
import { LandingHero } from "@/components/brand/LandingHero";
import { MotionRibbon } from "@/components/brand/MotionRibbon";
import { ScrollHeading } from "@/components/brand/ScrollHeading";
import { BrandSignoff } from "@/components/brand/BrandSignoff";
import { ProductCard } from "@/components/brand/ProductCard";
import { Reveal } from "@/components/brand/Reveal";
import { SiteLayout } from "@/components/brand/SiteLayout";
import { categories, pageCopy, stockAssets } from "@/data/homeContent";
import { categoryPaths, products } from "@/data/catalog";

function KeycapScrollLens() {
  const sectionRef = useRef<HTMLElement>(null);
  const shouldReduce = useReducedMotion() ?? false;
  const animate = !shouldReduce;
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end end"],
  });
  const progress = useSpring(scrollYProgress, {
    stiffness: 90,
    damping: 25,
    restDelta: 0.001,
  });
  const scale = useTransform(progress, [0, 0.65, 1], [0.76, 1, 1.12]);
  const y = useTransform(progress, [0, 1], [40, -12]);
  const rotateX = useTransform(progress, [0, 0.75, 1], [42, 0, 0]);
  const rotateZ = useTransform(progress, [0, 0.75, 1], [-7, 0, 0]);
  const detailOpacity = useTransform(progress, [0.2, 0.72], [0, 1]);
  const captionY = useTransform(scrollYProgress, [0, 1], [18, 0]);
  const captionOpacity = useTransform(
    scrollYProgress,
    [0.05, 0.3, 0.7],
    [0.25, 1, 1]
  );

  return (
    <section
      className="scroll-lens"
      data-motion={animate ? "enabled" : "off"}
      ref={sectionRef}
      aria-labelledby="scroll-lens-title"
    >
      <div className="scroll-lens-sticky page-width">
        <div className="scroll-lens-copy">
          <p className="eyebrow">
            <span className="eyebrow-mark" aria-hidden="true" />
            01 / THE KEYCAP LENS
          </p>
          <h2 id="scroll-lens-title">{pageCopy.flowTitle}</h2>
          <p>{pageCopy.flowDescription}</p>
          <span className="scroll-instruction">
            <ArrowDown size={14} aria-hidden="true" /> Scroll to move from setup
            to detail
          </span>
          <Link className="lens-explore" href="/categories/keycaps">
            Explore keycaps <ArrowUpRight size={15} aria-hidden="true" />
          </Link>
        </div>
        <div
          className="scroll-lens-visual"
          aria-label="Illustrative stock keyboard photo that zooms in as you scroll"
        >
          <div className="lens-frame-back" aria-hidden="true" />
          <motion.figure
            className="lens-photo"
            style={{
              scale: animate ? scale : 1,
              y: animate ? y : 0,
              rotateX: animate ? rotateX : 0,
              rotateZ: animate ? rotateZ : 0,
            }}
          >
            <img
              src={stockAssets.setup.src}
              alt={stockAssets.setup.alt}
              loading="lazy"
              decoding="async"
            />
            <motion.img
              className="lens-detail-image"
              src={stockAssets.keyboard.src}
              alt={stockAssets.keyboard.alt}
              loading="lazy"
              decoding="async"
              style={{ opacity: animate ? detailOpacity : 1 }}
            />
            <div className="lens-crosshair" aria-hidden="true">
              <span />
              <i />
            </div>
            <figcaption>
              STOCK PHOTOS · {stockAssets.setup.credit} /{" "}
              {stockAssets.keyboard.credit} · NOT A THIRD EYE GAMING PRODUCT
            </figcaption>
          </motion.figure>
          <motion.div
            className="lens-caption"
            style={{
              y: animate ? captionY : 0,
              opacity: animate ? captionOpacity : 1,
            }}
          >
            <span className="lens-caption-index">01 / DETAIL</span>
            <span>
              Keycaps change the way a keyboard reads. The exact product is
              still to come.
            </span>
          </motion.div>
          <div className="lens-magnify" aria-hidden="true">
            <span>KEYCAP STUDY</span>
            <i />
            <i />
            <i />
            <i />
          </div>
        </div>
      </div>
      <div className="scroll-lens-progress" aria-hidden="true">
        <motion.span style={{ scaleX: animate ? scrollYProgress : 1 }} />
      </div>
    </section>
  );
}

function FeaturedCategoryFlow() {
  const shouldReduce = useReducedMotion() ?? false;
  return (
    <section className="flow-section" aria-labelledby="flow-title">
      <div className="page-width flow-header">
        <div>
          <p className="eyebrow">
            <span className="eyebrow-mark" aria-hidden="true" />
            03 / FIVE TOUCHPOINTS
          </p>
          <h2 id="flow-title">Move through the details.</h2>
        </div>
        <p>
          From the keys beneath your fingers to the mouse in your hand, explore
          each part of the setup.
        </p>
      </div>
      <div className="flow-track-viewport">
        <div className="flow-track page-width">
          {categories.map((category, index) => (
            <motion.div
              key={category.id}
              className="flow-card-wrap"
              initial={
                shouldReduce
                  ? false
                  : { opacity: 0, y: 24, rotateY: index % 2 ? -7 : 7 }
              }
              whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: shouldReduce ? 0.01 : 0.52,
                delay: shouldReduce ? 0 : index * 0.07,
              }}
              whileHover={
                shouldReduce
                  ? undefined
                  : { y: -6, rotateX: -2, rotateY: index % 2 ? 2 : -2 }
              }
            >
              <Link
                className="flow-card"
                href={categoryPaths[category.id]}
                style={
                  {
                    "--category-accent": category.accent,
                    "--category-foreground": category.foreground,
                  } as React.CSSProperties
                }
              >
                <span className="flow-card-number">{category.number} / 05</span>
                <span className="flow-card-symbol" aria-hidden="true">
                  <i />
                  <i />
                  <i />
                  <i />
                  <b />
                </span>
                <span className="flow-card-copy">
                  <span>{category.eyebrow}</span>
                  <strong>{category.name}</strong>
                  <small>{category.description}</small>
                </span>
                <ArrowUpRight
                  className="flow-card-arrow"
                  size={18}
                  aria-hidden="true"
                />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
      <div className="page-width flow-footnote">
        <span>01—05 / CATEGORY FLOW</span>
        <span>
          Illustrative category markers only — not product renderings.
        </span>
        <Link href="/shop">
          Shop all accessories <ChevronRight size={15} aria-hidden="true" />
        </Link>
      </div>
    </section>
  );
}

export default function Home() {
  const featuredProducts = products
    .filter(product => product.featured)
    .slice(0, 5);

  return (
    <SiteLayout>
      <PageMeta title={pageCopy.title} description={pageCopy.description} />
      <main id="main-content">
        <LandingHero />

        <BrandVisionBanner />

        <MotionRibbon />

        <KeycapScrollLens />

        <section
          className="featured-section page-width"
          id="featured"
          aria-labelledby="featured-title"
        >
          <Reveal
            className="section-heading section-heading-split"
            as="section"
          >
            <div>
              <p className="eyebrow">
                <span className="eyebrow-mark" aria-hidden="true" />
                02 / A FIRST LOOK
              </p>
              <h2 id="featured-title">{pageCopy.featuredTitle}</h2>
            </div>
            <p className="section-intro">{pageCopy.featuredDescription}</p>
          </Reveal>
          <div className="featured-grid">
            {featuredProducts.map(product => (
              <Reveal key={product.id} delay={0.04}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
          <p className="sample-disclaimer">
            <span className="placeholder-dot" aria-hidden="true" />
            Sample product names and INR prices are illustrative preview data,
            not final product listings or offers.
          </p>
        </section>

        <FeaturedCategoryFlow />

        <Reveal as="section" className="brand-section" delay={0.02}>
          <div className="page-width brand-layout" id="brand">
            <div className="brand-side">
              <p className="eyebrow">
                <span className="eyebrow-mark" aria-hidden="true" />
                04 / OUR POINT OF VIEW
              </p>
              <div className="brand-side-number">
                TEG<span>—</span>01
              </div>
            </div>
            <div className="brand-main">
              <ScrollHeading text={pageCopy.brandTitle} />
              <p className="brand-description">{pageCopy.brandDescription}</p>
              <div className="principles-grid">
                <div>
                  <span>01</span>
                  <h3>Design, with focus.</h3>
                  <p>
                    Accessories are the point. The choices around form and
                    detail should feel intentional.
                  </p>
                </div>
                <div>
                  <span>02</span>
                  <h3>Comfort, in the small things.</h3>
                  <p>
                    The brand is built around noticing the little things that
                    matter in daily use.
                  </p>
                </div>
                <div>
                  <span>03</span>
                  <h3>Made for every setup.</h3>
                  <p>
                    For gaming, work, casual play, or simply anyone with a mouse
                    and keyboard.
                  </p>
                </div>
              </div>
              <Link className="brand-link" href="/about">
                Read our point of view{" "}
                <ArrowUpRight size={16} aria-hidden="true" />
              </Link>
            </div>
          </div>
        </Reveal>

        <section className="closing-section page-width">
          <Reveal className="closing-card" as="div">
            <div className="closing-index">
              <span>THIRD EYE GAMING</span>
              <span>AN ACCESSORY BRAND / INDIA</span>
            </div>
            <div className="closing-copy">
              <p className="eyebrow">THE NEXT LAYER OF YOUR SETUP</p>
              <h2>{pageCopy.closingTitle}</h2>
              <Link className="button-primary" href="/shop">
                Explore the categories{" "}
                <ArrowDownRight size={17} aria-hidden="true" />
              </Link>
            </div>
            <div className="closing-mark" aria-hidden="true">
              <span />
              <span />
              <span />
              <span />
              <i />
            </div>
          </Reveal>
        </section>
        <BrandSignoff />
      </main>
    </SiteLayout>
  );
}
