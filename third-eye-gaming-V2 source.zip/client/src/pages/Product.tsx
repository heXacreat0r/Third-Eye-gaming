import { ArrowLeft, ArrowUpRight, ShoppingBag } from "lucide-react";
import { ProductPresentation } from "@/components/brand/ProductPresentation";
import { Link } from "wouter";
import { PageMeta } from "@/components/brand/PageMeta";
import { SketchfabViewer } from "@/components/brand/SketchfabViewer";
import { SiteLayout } from "@/components/brand/SiteLayout";
import { useCart } from "@/contexts/CartContext";
import {
  categoryPaths,
  formatINR,
  getCategory,
  getProduct,
  getVisualAsset,
  retailers,
} from "@/data/catalog";
import NotFound from "@/pages/NotFound";

export default function ProductPage({ productId }: { productId: string }) {
  const product = getProduct(productId);
  if (!product) return <NotFound />;
  return <ProductDetail product={product} />;
}

function ProductDetail({
  product,
}: {
  product: NonNullable<ReturnType<typeof getProduct>>;
}) {
  const category = getCategory(product.categoryId);
  const image = getVisualAsset(product.visual);
  const { add } = useCart();
  const modelKind = product.detailModel ?? null;

  const title = `${product.name} | ${category.name} | Third Eye Gaming`;
  const description = `${product.description} Illustrative sample product page from Third Eye Gaming.`;

  return (
    <SiteLayout>
      <PageMeta title={title} description={description} />
      <main id="main-content" className="page-main product-page">
        <div className="page-width product-breadcrumb">
          <Link href={categoryPaths[product.categoryId]}>
            <ArrowLeft size={14} aria-hidden="true" /> {category.name}
          </Link>
          <span>/</span>
          <span>{product.name}</span>
        </div>
        <section className="product-detail page-width">
          <div className="product-visual-column">
            <ProductPresentation
              className={`product-card-visual-${product.visual}`}
            >
              {image ? (
                <img
                  src={image.src}
                  alt={image.alt}
                  fetchPriority="high"
                  decoding="async"
                />
              ) : (
                <div className="keychain-orbit" aria-hidden="true">
                  <span className="keychain-ring" />
                  <span className="keycap-shape">T</span>
                  <span className="orbit-dot" />
                </div>
              )}
              <span className="product-media-label">
                {image
                  ? `Stock photo · ${image.credit} · not a Third Eye Gaming product`
                  : "Abstract visual · not a product image"}
              </span>
              <span className="product-comet-stamp">
                {category.number} / 05
                <br />
                COMET VIEW
              </span>
            </ProductPresentation>
          </div>
          <div className="product-detail-copy">
            <p className="eyebrow">
              <span className="eyebrow-mark" aria-hidden="true" />
              {category.name.toUpperCase()} / PREVIEW
            </p>
            <h1>{product.name}</h1>
            <p className="product-detail-description">{product.description}</p>
            <div className="product-detail-price">
              <strong>{formatINR(product.price)}</strong>
              <span>Illustrative sample price · INR · not final</span>
            </div>
            <div className="product-preview-flag">
              <span className="placeholder-dot" aria-hidden="true" />
              Sample product name, price and imagery for preview only.
            </div>
            <div className="product-actions">
              <button
                className="button-primary"
                type="button"
                onClick={() => add(product.id)}
              >
                Add to preview cart <ShoppingBag size={16} aria-hidden="true" />
              </button>
              <Link
                className="button-text"
                href={categoryPaths[product.categoryId]}
              >
                More in {category.name}{" "}
                <ArrowUpRight size={14} aria-hidden="true" />
              </Link>
            </div>
            <div className="retailer-box">
              <p className="eyebrow">GENERAL RETAILER HOME PAGES</p>
              <p>
                These links go to the retailer homepage, not a product-specific
                listing for this sample item.
              </p>
              <div>
                {retailers.map(retailer => (
                  <a
                    key={retailer.name}
                    href={retailer.href}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Browse {retailer.name}{" "}
                    <ArrowUpRight size={14} aria-hidden="true" />
                  </a>
                ))}
              </div>
            </div>
            <details className="product-details-accordion">
              <summary>Preview and policy notes</summary>
              <p>
                Names and sample prices are illustrative. Actual materials,
                compatibility, product imagery and final prices are pending.
                Retailer availability, shipping and checkout are controlled by
                the retailer.
              </p>
            </details>
          </div>
        </section>
        {modelKind && (
          <section className="product-viewer-section page-width">
            <div className="product-viewer-heading">
              <div>
                <p className="eyebrow">INTERACTIVE REFERENCE / 360°</p>
                <h2>
                  {modelKind === "keyboard"
                    ? "A keyboard, seen from every side."
                    : "A mouse, turned all the way around."}
                </h2>
              </div>
              <p>
                Use the embedded viewer controls to drag and zoom. The model is
                a licensed reference only, not a Third Eye Gaming product.
              </p>
            </div>
            <SketchfabViewer kind={modelKind} />
          </section>
        )}
        <section className="product-details-note page-width">
          <div>
            <p className="eyebrow">PRODUCT DETAILS</p>
            <h2>Details will be finalized with the product.</h2>
          </div>
          <p>
            No unverified material, dimension, fit, or performance claims are
            included. Product-specific details will replace these preview notes
            when the finalized list is available.
          </p>
        </section>
      </main>
    </SiteLayout>
  );
}
