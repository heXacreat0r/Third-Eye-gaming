import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import { PageMeta } from "@/components/brand/PageMeta";
import { Reveal } from "@/components/brand/Reveal";
import { SiteLayout } from "@/components/brand/SiteLayout";

export default function AboutPage() {
  return <SiteLayout>
    <PageMeta title="About Third Eye Gaming | Design for the details" description="Learn about Third Eye Gaming, an accessories brand for mouse-and-keyboard setups focused on design, comfort and the small details that matter." />
    <main id="main-content" className="page-main about-page">
      <section className="about-hero page-width"><p className="eyebrow"><span className="eyebrow-mark" aria-hidden="true" />ABOUT / OUR POINT OF VIEW</p><h1>A different kind of gaming brand.</h1><p>Third Eye Gaming makes accessories for the mouse-and-keyboard setup you already own—not another complete peripheral line.</p><div className="about-hero-mark" aria-hidden="true"><span /><span /><span /><span /><i /></div></section>
      <Reveal as="section" className="about-story"><div className="page-width about-story-grid"><p className="eyebrow">THE NAME / THE INTENT</p><div><h2>Open another dimension for your gaming setup.</h2><p>The name Third Eye Gaming is about seeing the setup differently: noticing the small details that matter in daily use, and giving them more intention.</p><p>The brand stands for luxury and comfort in the details. That means focusing on the design of accessories for people who use a mouse and keyboard for gaming, work, casual play, and everything in between.</p></div></div></Reveal>
      <section className="about-pillars page-width"><article><span>01</span><h2>Accessories are the point.</h2><p>Keycaps, artisan keycaps, keycap keychains, mouse grips and mouse skates are the categories supplied for the first catalogue.</p></article><article><span>02</span><h2>Design with a purpose.</h2><p>The brand's distinction is its design focus and the care given to the small details—not competing as a full peripheral brand.</p></article><article><span>03</span><h2>Built to collaborate.</h2><p>Third Eye Gaming can manufacture accessories for other brands as well as sell under its own name.</p></article></section>
      <div className="about-cta page-width"><p className="eyebrow">FIND YOUR TOUCHPOINT</p><h2>Explore the categories.</h2><Link className="button-primary" href="/shop">Shop accessories <ArrowUpRight size={15} aria-hidden="true" /></Link></div>
    </main>
  </SiteLayout>;
}
