import { useEffect } from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { SiteLayout } from "@/components/brand/SiteLayout";

const NOT_FOUND_PATH = "/404";

export default function NotFound() {
  useEffect(() => {
    document.title = "Page not found | Third Eye Gaming";
    let robots = document.head.querySelector<HTMLMetaElement>('meta[name="robots"]');
    if (!robots) {
      robots = document.createElement("meta");
      robots.name = "robots";
      document.head.appendChild(robots);
    }
    robots.content = "noindex";
    if (window.location.pathname.replace(/\/$/, "") !== NOT_FOUND_PATH) window.location.replace(NOT_FOUND_PATH);
    return () => robots?.remove();
  }, []);

  return <SiteLayout>
    <main id="main-content" className="not-found page-width">
      <div><p className="eyebrow"><span className="eyebrow-mark" aria-hidden="true" />404 / NOT FOUND</p><h1>That page isn't here.</h1><p>The address may have changed. Your setup is still in good hands—head back to the home page or explore the accessories.</p><Link className="button-primary" href="/">Return home <ArrowLeft size={15} aria-hidden="true" /></Link></div>
      <span className="not-found-index" aria-hidden="true">TEG / 404</span>
    </main>
  </SiteLayout>;
}
