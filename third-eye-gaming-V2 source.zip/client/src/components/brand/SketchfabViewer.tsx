import { ExternalLink, Rotate3D } from "lucide-react";
import { modelReferences, superlightReference } from "@/data/catalog";

type SketchfabViewerProps = { kind: "keyboard" | "mouse"; className?: string };

export function SketchfabViewer({
  kind,
  className = "",
}: SketchfabViewerProps) {
  const model = modelReferences[kind];
  const isMouse = kind === "mouse";
  const embedUrl = `https://sketchfab.com/models/${model.uid}/embed?autostart=0&ui_infos=0&ui_controls=1&ui_watermark=1&ui_watermark_link=1`;

  return (
    <figure className={`model-viewer ${className}`}>
      <div className="model-viewer-frame">
        <>
          <iframe
            title={`${model.title} — interactive 3D reference model`}
            src={embedUrl}
            loading="lazy"
            allow="autoplay; fullscreen; xr-spatial-tracking"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />
          <div className="model-viewer-hint">
            <Rotate3D size={14} aria-hidden="true" />
            <span>Drag to rotate · scroll or pinch to zoom</span>
          </div>
        </>
      </div>
      <figcaption className="model-viewer-credit">
        <div>
          <span className="eyebrow">
            LICENSED REFERENCE MODEL · NOT A THIRD EYE PRODUCT
          </span>
          <p>
            “{model.title}” by {model.creator} ·{" "}
            <a href={model.source} target="_blank" rel="noreferrer">
              Source
            </a>{" "}
            ·{" "}
            <a href={model.licenseUrl} target="_blank" rel="noreferrer">
              {model.license}
            </a>
            .
          </p>
          <p className="model-viewer-fallback-note">
            If the embedded model is blocked or remains blank, open it on
            Sketchfab using the source link.
          </p>
          {isMouse && (
            <p className="model-dimensions">
              Fit reference: {superlightReference.name},{" "}
              {superlightReference.dimensions}. {superlightReference.note}
            </p>
          )}
        </div>
        <a
          className="model-fallback-link"
          href={model.source}
          target="_blank"
          rel="noreferrer"
          aria-label={`Open ${model.title} on Sketchfab`}
        >
          Open model page <ExternalLink size={13} aria-hidden="true" />
        </a>
      </figcaption>
    </figure>
  );
}
