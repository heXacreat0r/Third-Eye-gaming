import { useRef } from "react";
import {
  motion,
  useReducedMotion,
  useScroll,
  useTransform,
  type MotionValue,
} from "framer-motion";

function Word({
  word,
  progress,
  start,
  end,
  reduced,
}: {
  word: string;
  progress: MotionValue<number>;
  start: number;
  end: number;
  reduced: boolean;
}) {
  const opacity = useTransform(progress, [start, end], [0.55, 1]);
  const y = useTransform(progress, [start, end], [6, 0]);
  return (
    <motion.span
      aria-hidden="true"
      style={reduced ? undefined : { opacity, y }}
    >
      {word}
    </motion.span>
  );
}

export function ScrollHeading({
  text,
  id,
  className = "",
}: {
  text: string;
  id?: string;
  className?: string;
}) {
  const ref = useRef<HTMLHeadingElement>(null);
  const reduced = useReducedMotion() ?? false;
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 90%", "end 45%"],
  });
  const words = text.split(" ");
  return (
    <h2
      ref={ref}
      id={id}
      className={`scroll-heading ${className}`}
      aria-label={text}
    >
      {words.map((word, index) => (
        <span className="scroll-heading-word" key={`${index}-${word}`}>
          <Word
            word={word}
            progress={scrollYProgress}
            start={(index / words.length) * 0.8}
            end={(index / words.length) * 0.8 + 0.2}
            reduced={reduced}
          />{" "}
        </span>
      ))}
    </h2>
  );
}
