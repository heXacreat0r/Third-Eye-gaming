import { ArrowUpRight, ShoppingBag } from "lucide-react";
import { Link } from "wouter";
import { useCart } from "@/contexts/CartContext";
import { CometCard } from "./CometCard";
import {
  categoryPaths,
  formatINR,
  getCategory,
  getProductPath,
  getVisualAsset,
  type Product,
} from "@/data/catalog";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const category = getCategory(product.categoryId);
  const image = getVisualAsset(product.visual);

  return (
    <div
      style={
        {
          "--category-accent": category.accent,
          "--category-foreground": category.foreground,
        } as React.CSSProperties
      }
    >
      <CometCard compact className="product-card">
        <Link
          className="product-card-link"
          href={getProductPath(product)}
          aria-label={`View ${product.name} preview`}
        >
          <div
            className={`product-card-visual product-card-visual-${product.visual}`}
          >
            {image ? (
              <img
                src={image.src}
                alt={image.alt}
                loading="eager"
                decoding="async"
              />
            ) : (
              <div className="keychain-orbit" aria-hidden="true">
                <span className="keychain-ring" />
                <span className="keycap-shape">T</span>
                <span className="orbit-dot" />
              </div>
            )}
            <span className="product-media-label">
              {image
                ? `Stock photo · ${image.credit} · not a Third Eye Gaming product`
                : "Abstract visual · not a product image"}
            </span>
            {product.featured && (
              <span className="product-featured-badge">Featured</span>
            )}
          </div>
          <div className="product-card-copy">
            <p className="eyebrow">{category.name.toUpperCase()}</p>
            <h3>{product.name}</h3>
            <p className="product-card-description">{product.description}</p>
            <div className="product-price-row">
              <strong>{formatINR(product.price)}</strong>
              <span>Sample price</span>
            </div>
          </div>
        </Link>
        <div className="product-card-actions">
          <Link className="product-view-link" href={getProductPath(product)}>
            View preview <ArrowUpRight size={14} aria-hidden="true" />
          </Link>
          <button
            className="product-add-button"
            type="button"
            onClick={() => add(product.id)}
            aria-label={`Add ${product.name} sample to preview cart`}
          >
            <ShoppingBag size={15} aria-hidden="true" />
            <span>Add</span>
          </button>
        </div>
        <Link
          className="product-category-link"
          href={categoryPaths[product.categoryId]}
          aria-label={`Browse ${category.name}`}
        >
          Browse category
        </Link>
      </CometCard>
    </div>
  );
}
