import { useRef } from "react";
import { useInView, useReducedMotion } from "framer-motion";

const labels = [
  "THIRD EYE GAMING",
  "KEYBOARD DETAILS",
  "MOUSE DETAILS",
  "COMFORT / FORM / FOCUS",
];

export function MotionRibbon() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { margin: "80px" });
  const reduced = useReducedMotion();
  return (
    <div
      ref={ref}
      className="editorial-ribbon motion-ribbon"
      tabIndex={0}
      aria-label="Brand focus. Focus or hover to pause the moving text."
    >
      <span className="sr-only">{labels.join(". ")}</span>
      <div
        className="motion-ribbon-track"
        aria-hidden="true"
        data-motion={reduced ? "off" : "enabled"}
        style={{
          animationPlayState: inView && !reduced ? "running" : "paused",
        }}
      >
        {[0, 1].map(copy => (
          <div className="motion-ribbon-group" key={copy}>
            {labels.map(label => (
              <span key={label}>
                <i aria-hidden="true" />
                {label}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
