import { useEffect, useRef, useState, type FocusEvent } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowUpRight,
  ChevronDown,
  Menu,
  Moon,
  ShoppingBag,
  Sun,
  X,
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { useTheme } from "@/contexts/ThemeContext";
import { categories, categoryPaths } from "@/data/catalog";

type SiteHeaderProps = { itemCount: number; onOpenCart: () => void };

export function SiteHeader({ itemCount, onOpenCart }: SiteHeaderProps) {
  const { theme, toggleTheme } = useTheme();
  const reduceMotion = useReducedMotion();
  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [rawLocation] = useLocation();
  const location = rawLocation.replace(/\/+$/, "") || "/";
  const headerRef = useRef<HTMLElement>(null);
  const shopRef = useRef<HTMLButtonElement>(null);
  const mobileRef = useRef<HTMLButtonElement>(null);
  const logo =
    theme === "dark"
      ? "/assets/third-eye-logo-dark.png"
      : "/assets/third-eye-logo-light.png";

  useEffect(() => {
    setMenuOpen(false);
    setMobileOpen(false);
  }, [location]);

  useEffect(() => {
    if (!menuOpen && !mobileOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        (mobileOpen ? mobileRef : shopRef).current?.focus();
        setMenuOpen(false);
        setMobileOpen(false);
      }
    };
    document.addEventListener("keydown", onKeyDown);
    const onOutside = (event: globalThis.PointerEvent) => {
      if (!headerRef.current?.contains(event.target as Node)) {
        setMenuOpen(false);
        setMobileOpen(false);
      }
    };
    const onResize = () => {
      setMenuOpen(false);
      setMobileOpen(false);
    };
    document.addEventListener("pointerdown", onOutside);
    window.addEventListener("resize", onResize);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("pointerdown", onOutside);
      window.removeEventListener("resize", onResize);
    };
  }, [menuOpen, mobileOpen]);

  const closeMenus = () => {
    setMenuOpen(false);
    setMobileOpen(false);
  };
  const onHeaderBlur = (event: FocusEvent<HTMLElement>) => {
    if (!event.currentTarget.contains(event.relatedTarget as Node | null))
      closeMenus();
  };

  return (
    <header
      ref={headerRef}
      className="site-header"
      onMouseLeave={() => {
        if (!headerRef.current?.contains(document.activeElement))
          setMenuOpen(false);
      }}
      onBlur={onHeaderBlur}
    >
      <div className="header-inner page-width">
        <Link
          className="brand-home logo-ink-sweep"
          href="/"
          aria-label="Third Eye Gaming home"
          onClick={closeMenus}
          onPointerMove={event => {
            if (reduceMotion || event.pointerType !== "mouse") return;
            const bounds = event.currentTarget.getBoundingClientRect();
            event.currentTarget.style.setProperty(
              "--logo-x",
              `${event.clientX - bounds.left}px`
            );
            event.currentTarget.style.setProperty(
              "--logo-y",
              `${event.clientY - bounds.top}px`
            );
          }}
        >
          <img src={logo} alt="Third Eye Gaming" width="228" height="64" />
          <span className="logo-sweep-line" aria-hidden="true" />
          <span
            className="logo-spotlight"
            aria-hidden="true"
            style={{
              maskImage: `url(${logo})`,
              WebkitMaskImage: `url(${logo})`,
            }}
          />
        </Link>

        <nav className="desktop-nav" aria-label="Main navigation">
          <Link href="/" aria-current={location === "/" ? "page" : undefined}>
            Home
          </Link>
          <button
            ref={shopRef}
            className={`mega-trigger${location.startsWith("/shop") || location.startsWith("/categories/") || location.startsWith("/products/") ? " is-active" : ""}`}
            type="button"
            onClick={() => setMenuOpen(value => !value)}
            onKeyDown={event => {
              if (event.key === "ArrowDown") {
                event.preventDefault();
                setMenuOpen(true);
                requestAnimationFrame(() =>
                  document
                    .querySelector<HTMLAnchorElement>("#shop-mega-menu a")
                    ?.focus()
                );
              }
            }}
            aria-expanded={menuOpen}
            aria-controls="shop-mega-menu"
          >
            Shop{" "}
            <ChevronDown
              size={14}
              className={menuOpen ? "chevron-open" : ""}
              aria-hidden="true"
            />
          </button>
          <Link
            href="/about"
            aria-current={location === "/about" ? "page" : undefined}
          >
            About
          </Link>
          <Link
            href="/support"
            aria-current={location === "/support" ? "page" : undefined}
          >
            Support
          </Link>
        </nav>

        <div className="header-actions">
          <button
            className="icon-button theme-toggle"
            type="button"
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
            title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
          >
            {theme === "dark" ? (
              <Sun size={17} strokeWidth={1.7} />
            ) : (
              <Moon size={17} strokeWidth={1.7} />
            )}
          </button>
          <button
            className="cart-trigger"
            type="button"
            onClick={() => {
              closeMenus();
              onOpenCart();
            }}
            aria-label={`Open preview cart, ${itemCount} items`}
          >
            <ShoppingBag size={17} strokeWidth={1.7} />
            <span>Cart</span>
            <span className="cart-count" aria-hidden="true">
              {itemCount}
            </span>
          </button>
          <button
            ref={mobileRef}
            className="icon-button menu-toggle"
            type="button"
            onClick={() => setMobileOpen(value => !value)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-menu"
            aria-label={
              mobileOpen ? "Close navigation menu" : "Open navigation menu"
            }
          >
            {mobileOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            id="shop-mega-menu"
            style={{ x: "-50%" }}
            className="mega-menu page-width"
            role="region"
            aria-label="Shop categories"
            initial={reduceMotion ? false : { opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduceMotion ? undefined : { opacity: 0, y: -8 }}
            transition={{ duration: reduceMotion ? 0 : 0.18 }}
          >
            <div className="mega-intro">
              <p className="eyebrow">SHOP / BY DETAIL</p>
              <h2>Choose your touchpoint.</h2>
              <p>
                Accessories for the keyboard and mouse already in your setup.
              </p>
              <Link className="mega-all-link" href="/shop" onClick={closeMenus}>
                Explore all accessories{" "}
                <ArrowUpRight size={14} aria-hidden="true" />
              </Link>
            </div>
            <div
              className="mega-category-list"
              aria-label="Accessory categories"
            >
              {categories.map(category => (
                <Link
                  key={category.id}
                  href={categoryPaths[category.id]}
                  onClick={closeMenus}
                  style={
                    {
                      "--category-accent": category.accent,
                    } as React.CSSProperties
                  }
                >
                  <span className="mega-category-number">
                    {category.number}
                  </span>
                  <span>
                    <strong>{category.name}</strong>
                    <small>{category.eyebrow}</small>
                  </span>
                  <ArrowUpRight size={14} aria-hidden="true" />
                </Link>
              ))}
            </div>
            <button
              className="mega-close"
              type="button"
              onClick={() => {
                setMenuOpen(false);
                shopRef.current?.focus();
              }}
              aria-label="Close shop menu"
            >
              <X size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {mobileOpen && (
        <nav
          id="mobile-menu"
          className="mobile-nav is-open"
          aria-label="Mobile navigation"
        >
          <Link
            href="/"
            onClick={closeMenus}
            aria-current={location === "/" ? "page" : undefined}
          >
            Home
          </Link>
          <Link href="/shop" onClick={closeMenus}>
            Shop all accessories
          </Link>
          {categories.map(category => (
            <Link
              key={category.id}
              href={categoryPaths[category.id]}
              onClick={closeMenus}
            >
              <span className="nav-number">{category.number}</span>
              {category.name}
            </Link>
          ))}
          <Link href="/about" onClick={closeMenus}>
            About
          </Link>
          <Link href="/support" onClick={closeMenus}>
            Support
          </Link>
        </nav>
      )}
    </header>
  );
}
