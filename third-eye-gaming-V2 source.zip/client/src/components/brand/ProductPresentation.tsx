import { useId, useState, type ReactNode } from "react";
import { useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight, RotateCcw } from "lucide-react";
import { CometCard } from "./CometCard";

export function ProductPresentation({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const reduced = useReducedMotion();
  const [pose, setPose] = useState({ x: 0, y: 0 });
  const enabled = !reduced;
  const hintId = useId();
  return (
    <div className="product-presentation">
      <CometCard className={`product-comet-card ${className}`} pose={pose}>
        {children}
      </CometCard>
      <div
        className="presentation-controls"
        role="group"
        aria-label="Image perspective controls"
        aria-describedby={hintId}
      >
        <button
          type="button"
          disabled={!enabled}
          onClick={() => setPose({ x: -0.85, y: 0.4 })}
          aria-label="Tilt image left"
        >
          <ArrowLeft size={16} />
        </button>
        <button
          type="button"
          onClick={() => setPose({ x: 0, y: 0 })}
          aria-label="Reset image perspective"
        >
          <RotateCcw size={15} />
        </button>
        <button
          type="button"
          disabled={!enabled}
          onClick={() => setPose({ x: 0.85, y: 0.4 })}
          aria-label="Tilt image right"
        >
          <ArrowRight size={16} />
        </button>
      </div>
      <p id={hintId} className="model-tilt-note">
        {enabled
          ? "Move your pointer, swipe across the image, or use the arrows to explore depth and light."
          : "Motion is reduced to match your device preference."}{" "}
        Single-image perspective; full product rotation awaits product assets.
      </p>
    </div>
  );
}
