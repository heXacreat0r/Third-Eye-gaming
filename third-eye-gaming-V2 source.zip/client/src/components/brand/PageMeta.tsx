import { useEffect } from "react";

const DEFAULT_KEYWORDS =
  "Third Eye Gaming, gaming accessories, mouse accessories, keycaps, artisan keycaps, keycap keychains, mouse grips, mouse skates";
const DEFAULT_IMAGE = "/assets/third-eye-logo-light.png";

type PageMetaProps = {
  title: string;
  description: string;
  keywords?: string;
  noindex?: boolean;
};

function setMeta(
  selector: string,
  key: string,
  value: string,
  attribute: "name" | "property" = "name"
) {
  let element = document.head.querySelector<HTMLMetaElement>(selector);
  if (!element) {
    element = document.createElement("meta");
    element.setAttribute(attribute, key);
    document.head.appendChild(element);
  }
  element.content = value;
}

export function PageMeta({
  title,
  description,
  keywords = DEFAULT_KEYWORDS,
  noindex = false,
}: PageMetaProps) {
  useEffect(() => {
    document.title = title;
    setMeta('meta[name="description"]', "description", description);
    setMeta('meta[name="keywords"]', "keywords", keywords);
    setMeta('meta[property="og:title"]', "og:title", title, "property");
    setMeta(
      'meta[property="og:description"]',
      "og:description",
      description,
      "property"
    );
    setMeta('meta[property="og:type"]', "og:type", "website", "property");
    setMeta(
      'meta[property="og:site_name"]',
      "og:site_name",
      "Third Eye Gaming",
      "property"
    );
    setMeta('meta[property="og:image"]', "og:image", DEFAULT_IMAGE, "property");
    setMeta(
      'meta[property="og:image:alt"]',
      "og:image:alt",
      "Third Eye Gaming temporary wordmark in the approved Ink & Aperture palette.",
      "property"
    );
    setMeta('meta[name="twitter:title"]', "twitter:title", title);
    setMeta(
      'meta[name="twitter:description"]',
      "twitter:description",
      description
    );
    setMeta('meta[name="twitter:image"]', "twitter:image", DEFAULT_IMAGE);
    setMeta(
      'meta[name="twitter:image:alt"]',
      "twitter:image:alt",
      "Third Eye Gaming temporary wordmark in the approved Ink & Aperture palette."
    );
    const existing = document.head.querySelector<HTMLMetaElement>(
      'meta[name="robots"]'
    );
    if (noindex) setMeta('meta[name="robots"]', "robots", "noindex");
    else existing?.remove();
  }, [title, description, keywords, noindex]);
  return null;
}
