import { Link } from "wouter";
import { categories, categoryPaths, retailers } from "@/data/catalog";

export function SiteFooter() {
  const logo = "/assets/third-eye-logo-dark.png";

  return (
    <footer className="site-footer">
      <div className="footer-main page-width">
        <div className="footer-brand">
          <Link
            href="/"
            className="footer-logo logo-ink-sweep"
            aria-label="Third Eye Gaming home"
          >
            <img
              src={logo}
              alt="Third Eye Gaming"
              width="210"
              height="59"
              loading="lazy"
            />
            <span className="logo-sweep-line" aria-hidden="true" />
          </Link>
          <p>
            Accessories for the small details that shape a mouse-and-keyboard
            setup.
          </p>
        </div>
        <div className="footer-links">
          <div>
            <p className="eyebrow">EXPLORE</p>
            <Link href="/shop">Shop all</Link>
            {categories.map(category => (
              <Link key={category.id} href={categoryPaths[category.id]}>
                {category.name}
              </Link>
            ))}
          </div>
          <div>
            <p className="eyebrow">THE BRAND</p>
            <Link href="/about">About Third Eye Gaming</Link>
            <Link href="/support">Support & policies</Link>
            <span>
              Product names and prices shown are illustrative preview data.
            </span>
          </div>
          <div>
            <p className="eyebrow">RETAILER HOME PAGES</p>
            {retailers.map(retailer => (
              <a
                key={retailer.name}
                href={retailer.href}
                target="_blank"
                rel="noreferrer"
              >
                {retailer.name} <span aria-hidden="true">↗</span>
              </a>
            ))}
            <span>Not product-specific listings.</span>
          </div>
        </div>
      </div>
      <div className="footer-bottom page-width">
        <span>© {new Date().getFullYear()} Third Eye Gaming</span>
        <span>Temporary wordmark · product imagery is illustrative</span>
        <a href="#top" className="back-top">
          Back to top <span aria-hidden="true">↑</span>
        </a>
      </div>
    </footer>
  );
}
