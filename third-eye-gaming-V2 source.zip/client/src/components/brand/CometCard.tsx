import { useEffect, useRef, type ReactNode } from "react";
import {
  motion,
  useMotionTemplate,
  useMotionValue,
  useReducedMotion,
  useSpring,
  useTransform,
} from "framer-motion";

type CometCardProps = {
  children: ReactNode;
  className?: string;
  compact?: boolean;
  pose?: { x: number; y: number };
};

/** Layered perspective inspired by Comet Card. Does not imply product rotation. */
export function CometCard({
  children,
  className = "",
  compact = false,
  pose,
}: CometCardProps) {
  const reduced = useReducedMotion();
  const enabled = !reduced;
  const touchStart = useRef<{ x: number; y: number } | null>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springX = useSpring(x, { stiffness: 125, damping: 19 });
  const springY = useSpring(y, { stiffness: 125, damping: 19 });
  const rotateX = useTransform(springY, [-1, 1], compact ? [6, -6] : [12, -12]);
  const rotateY = useTransform(springX, [-1, 1], compact ? [-8, 8] : [-17, 17]);
  const lightX = useTransform(springX, [-1, 1], ["0%", "100%"]);
  const lightY = useTransform(springY, [-1, 1], ["0%", "100%"]);
  const light = useMotionTemplate`radial-gradient(ellipse at ${lightX} ${lightY}, rgba(255,255,255,.30), transparent 65%)`;
  const rim = useMotionTemplate`radial-gradient(ellipse at ${lightX} ${lightY}, #ffb38e, rgba(228,92,50,.1) 70%)`;
  useEffect(() => {
    x.set(enabled ? (pose?.x ?? 0) : 0);
    y.set(enabled ? (pose?.y ?? 0) : 0);
  }, [pose, enabled, x, y]);
  const reset = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <div
      className={`comet-stage${compact ? " comet-compact" : " comet-detail"}`}
      data-motion={enabled ? "enabled" : "off"}
      onPointerDown={event => {
        if (enabled && event.pointerType === "touch")
          touchStart.current = { x: event.clientX, y: event.clientY };
      }}
      onPointerMove={event => {
        if (!enabled) return;
        if (event.pointerType !== "mouse") {
          if (!touchStart.current) return;
          const dx = event.clientX - touchStart.current.x;
          const dy = event.clientY - touchStart.current.y;
          if (Math.abs(dx) < 12 || Math.abs(dy) > Math.abs(dx)) return;
          event.currentTarget.setPointerCapture(event.pointerId);
        }
        // Measure the stable stage so moving the card cannot feed back into its tilt.
        const rect = event.currentTarget.getBoundingClientRect();
        x.set(
          Math.max(
            -1,
            Math.min(1, ((event.clientX - rect.left) / rect.width) * 2 - 1)
          )
        );
        y.set(
          Math.max(
            -1,
            Math.min(1, ((event.clientY - rect.top) / rect.height) * 2 - 1)
          )
        );
      }}
      onPointerLeave={reset}
      onPointerUp={() => {
        touchStart.current = null;
        reset();
      }}
      onPointerCancel={() => {
        touchStart.current = null;
        reset();
      }}
    >
      <motion.article
        className={`comet-frame ${className}`}
        style={enabled ? { rotateX, rotateY } : { rotateX: 0, rotateY: 0 }}
      >
        <span className="comet-backplate" aria-hidden="true" />
        {children}
        {enabled && (
          <>
            <motion.span
              className="comet-glare"
              aria-hidden="true"
              style={{ background: light }}
            />
            <motion.span
              className="comet-rim"
              aria-hidden="true"
              style={{ background: rim }}
            />
          </>
        )}
      </motion.article>
    </div>
  );
}
