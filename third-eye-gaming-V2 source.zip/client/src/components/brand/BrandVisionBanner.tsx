import { useRef } from "react";
import {
  motion,
  useInView,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import { pageCopy, stockAssets } from "@/data/homeContent";
import { ScrollHeading } from "./ScrollHeading";

export function BrandVisionBanner() {
  const sectionRef = useRef<HTMLElement>(null);
  const reduced = useReducedMotion();
  const inView = useInView(sectionRef, { margin: "100px" });
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });
  const progress = useSpring(scrollYProgress, { stiffness: 80, damping: 25 });
  const y = useTransform(progress, [0, 1], [-45, 45]);
  const scale = useTransform(progress, [0, 1], [1.04, 1.12]);

  return (
    <section
      ref={sectionRef}
      className="vision-banner"
      aria-labelledby="vision-banner-title"
      data-motion={reduced ? "off" : "enabled"}
    >
      <motion.div
        className="vision-banner-backdrop"
        aria-hidden="true"
        style={reduced ? undefined : { y, scale }}
      >
        <img
          src={stockAssets.keyboard.src}
          alt=""
          loading="lazy"
          decoding="async"
          style={{
            animationPlayState: inView && !reduced ? "running" : "paused",
          }}
        />
      </motion.div>
      <div className="vision-banner-shade" aria-hidden="true" />
      <div className="vision-banner-content page-width">
        <div className="vision-banner-topline">
          <p className="eyebrow">
            <span className="eyebrow-mark" aria-hidden="true" />
            THIRD EYE GAMING / OUR VISION
          </p>
          <span aria-hidden="true">FORM. FEEL. FOCUS.</span>
        </div>
        <div className="vision-banner-copy">
          <ScrollHeading id="vision-banner-title" text={pageCopy.visionTitle} />
          <p>{pageCopy.visionDescription}</p>
          <Link className="vision-banner-link" href="/about">
            Explore our point of view{" "}
            <ArrowUpRight size={17} aria-hidden="true" />
          </Link>
        </div>
        <div className="vision-banner-bottom">
          <span>DESIGN / COMFORT / SELF-EXPRESSION</span>
          <p>
            Illustrative stock image · {stockAssets.keyboard.credit}
            <br />
            Not a Third Eye Gaming product.
          </p>
        </div>
      </div>
    </section>
  );
}
