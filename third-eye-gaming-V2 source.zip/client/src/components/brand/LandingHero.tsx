import { useRef, type PointerEvent } from "react";
import {
  motion,
  useMotionValue,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import { pageCopy, stockAssets } from "@/data/homeContent";
import { Reveal } from "./Reveal";

export function LandingHero() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 25 });
  const photoY = useTransform(progress, [0, 1], [0, 95]);
  const photoRotate = useTransform(progress, [0, 1], [-3, 4]);
  const photoScale = useTransform(progress, [0, 1], [1, 0.94]);
  const backdropX = useTransform(progress, [0, 1], ["0%", "-8%"]);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const smoothX = useSpring(x, { stiffness: 130, damping: 22 });
  const smoothY = useSpring(y, { stiffness: 130, damping: 22 });
  const rotateX = useTransform(smoothY, [-1, 1], [5, -5]);
  const rotateY = useTransform(smoothX, [-1, 1], [-7, 7]);
  const reset = () => {
    x.set(0);
    y.set(0);
  };
  const move = (event: PointerEvent<HTMLDivElement>) => {
    if (reduced || event.pointerType !== "mouse") return;
    const bounds = event.currentTarget.getBoundingClientRect();
    x.set(
      Math.max(
        -1,
        Math.min(1, ((event.clientX - bounds.left) / bounds.width) * 2 - 1)
      )
    );
    y.set(
      Math.max(
        -1,
        Math.min(1, ((event.clientY - bounds.top) / bounds.height) * 2 - 1)
      )
    );
  };

  return (
    <div className="landing-hero" ref={sectionRef}>
      <div className="landing-hero-glow" aria-hidden="true" />
      <motion.div
        className="hero-ghost-word"
        aria-hidden="true"
        style={reduced ? undefined : { x: backdropX }}
      >
        THIRD EYE
      </motion.div>
      <section className="hero page-width" id="home">
        <div className="hero-copy">
          <Reveal delay={0.04}>
            <p className="eyebrow hero-eyebrow">
              <span className="eyebrow-mark" aria-hidden="true" />
              {pageCopy.heroEyebrow}
            </p>
          </Reveal>
          <h1 className="hero-reveal-title" aria-label={pageCopy.heroTitle}>
            {pageCopy.heroTitle.split(" ").map((word, index) => (
              <span
                className="hero-word-clip"
                key={`${index}-${word}`}
                aria-hidden="true"
              >
                <motion.span
                  initial={reduced ? false : { y: "108%", rotate: 4 }}
                  animate={{ y: "0%", rotate: 0 }}
                  transition={{
                    duration: 0.7,
                    delay: 0.08 * index + 0.08,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  {word}
                </motion.span>{" "}
              </span>
            ))}
          </h1>
          <Reveal delay={0.25}>
            <p className="hero-description">{pageCopy.heroDescription}</p>
          </Reveal>
          <Reveal delay={0.32}>
            <div className="hero-actions">
              <Link className="button-primary" href="/shop">
                Explore accessories{" "}
                <ArrowDownRight size={17} aria-hidden="true" />
              </Link>
              <Link className="button-text" href="/about">
                A different kind of brand{" "}
                <ArrowUpRight size={15} aria-hidden="true" />
              </Link>
            </div>
          </Reveal>
          <div className="hero-footnote">
            <span>01 / 05 — KEYBOARD & MOUSE ACCESSORIES</span>
            <span>MADE FOR THE DETAILS THAT MATTER</span>
          </div>
        </div>
        <div
          className="hero-art-wrap"
          onPointerMove={move}
          onPointerLeave={reset}
          onPointerCancel={reset}
        >
          <motion.div
            className="hero-float-shell"
            style={
              reduced
                ? undefined
                : { y: photoY, rotate: photoRotate, scale: photoScale }
            }
          >
            <div className="hero-art-backplate" aria-hidden="true" />
            <motion.figure
              className="hero-art"
              style={reduced ? undefined : { rotateX, rotateY }}
            >
              <img
                src={stockAssets.setup.src}
                alt={stockAssets.setup.alt}
                fetchPriority="high"
                decoding="async"
              />
              <div className="hero-photo-stamp">
                <span>SETUP STUDY / 01</span>
                <span>INDIA</span>
              </div>
              <figcaption className="hero-photo-caption">
                Illustrative stock photo · {stockAssets.setup.credit} · not a
                Third Eye Gaming product
              </figcaption>
            </motion.figure>
            <div className="hero-floating-note">
              <span className="floating-line" />
              <span>
                DESIGN
                <br />
                MEETS COMFORT
              </span>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
