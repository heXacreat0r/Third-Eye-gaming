import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useRef } from "react";
import { Link } from "wouter";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { formatINR, getCategory, getProduct, retailers } from "@/data/catalog";
import { MAX_CART_QUANTITY, type CartLine } from "@/contexts/CartContext";

type CartDrawerProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: CartLine[];
  onQuantityChange: (productId: string, quantity: number) => void;
  onRemove: (productId: string) => void;
};

export function CartDrawer({
  open,
  onOpenChange,
  items,
  onQuantityChange,
  onRemove,
}: CartDrawerProps) {
  const opener = useRef<HTMLElement | null>(null);
  const count = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce(
    (sum, item) =>
      sum + (getProduct(item.productId)?.price ?? 0) * item.quantity,
    0
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="cart-dialog top-0 right-0 bottom-0 left-auto translate-x-0 translate-y-0"
        showCloseButton={false}
        aria-describedby="cart-description"
        onOpenAutoFocus={() => {
          opener.current =
            document.activeElement instanceof HTMLElement
              ? document.activeElement
              : null;
        }}
        onCloseAutoFocus={event => {
          event.preventDefault();
          const target =
            opener.current?.isConnected && opener.current !== document.body
              ? opener.current
              : document.querySelector<HTMLElement>(".cart-trigger");
          target?.focus({ preventScroll: true });
        }}
      >
        <div className="cart-drawer-head">
          <div>
            <p className="eyebrow">
              PREVIEW CART / {String(count).padStart(2, "0")}
            </p>
            <DialogHeader>
              <DialogTitle>Your setup, in progress.</DialogTitle>
            </DialogHeader>
          </div>
          <DialogClose
            className="icon-button cart-close"
            aria-label="Close cart"
          >
            <span aria-hidden="true">×</span>
          </DialogClose>
        </div>
        <DialogDescription id="cart-description" className="cart-intro">
          A working preview cart using sample product names and illustrative INR
          prices only. No payment is taken here.
        </DialogDescription>

        {items.length === 0 ? (
          <div className="cart-empty">
            <div className="cart-empty-mark" aria-hidden="true">
              <ShoppingBag size={28} strokeWidth={1.2} />
            </div>
            <p className="eyebrow">NOTHING IN HERE YET</p>
            <h3>Start with a detail.</h3>
            <p>Choose a sample product and add it to your preview cart.</p>
            <Link
              className="text-link"
              href="/shop"
              onClick={() => onOpenChange(false)}
            >
              Explore accessories <span aria-hidden="true">↘</span>
            </Link>
          </div>
        ) : (
          <div
            className="cart-lines"
            role="list"
            aria-label="Preview cart items"
          >
            {items.map(item => {
              const product = getProduct(item.productId);
              if (!product) return null;
              const category = getCategory(product.categoryId);
              return (
                <article
                  className="cart-line"
                  key={item.productId}
                  role="listitem"
                >
                  <div
                    className="cart-line-mark"
                    style={{
                      backgroundColor: category.accent,
                      color: category.foreground,
                    }}
                    aria-hidden="true"
                  >
                    <span>{category.number}</span>
                  </div>
                  <div className="cart-line-copy">
                    <p className="eyebrow">
                      SAMPLE / {category.name.toUpperCase()}
                    </p>
                    <h3>
                      <Link
                        href={`/products/${product.id}`}
                        onClick={() => onOpenChange(false)}
                      >
                        {product.name}
                      </Link>
                    </h3>
                    <p>
                      {formatINR(product.price)} sample price × {item.quantity}
                    </p>
                    <div
                      className="quantity-control"
                      aria-label={`Quantity for ${product.name}`}
                    >
                      <button
                        type="button"
                        onClick={() =>
                          onQuantityChange(item.productId, item.quantity - 1)
                        }
                        aria-label={`Decrease ${product.name} quantity`}
                      >
                        <Minus size={14} />
                      </button>
                      <span aria-live="polite">{item.quantity}</span>
                      <button
                        type="button"
                        disabled={item.quantity >= MAX_CART_QUANTITY}
                        onClick={() =>
                          onQuantityChange(item.productId, item.quantity + 1)
                        }
                        aria-label={`Increase ${product.name} quantity`}
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                    <div className="cart-retailer-links">
                      {retailers.map(retailer => (
                        <a
                          key={retailer.name}
                          href={retailer.href}
                          target="_blank"
                          rel="noreferrer"
                        >
                          {retailer.name} <span aria-hidden="true">↗</span>
                        </a>
                      ))}
                    </div>
                  </div>
                  <button
                    className="remove-item"
                    type="button"
                    onClick={() => onRemove(item.productId)}
                    aria-label={`Remove ${product.name}`}
                  >
                    <Trash2 size={15} />
                  </button>
                </article>
              );
            })}
          </div>
        )}

        {items.length > 0 && (
          <div className="cart-subtotal">
            <span>Sample subtotal</span>
            <strong>{formatINR(subtotal)}</strong>
          </div>
        )}
        <div className="cart-drawer-foot">
          <p className="cart-disclaimer">
            Sample names and prices are illustrative, not final offers. Retailer
            buttons open general homepages, not product-specific listings. Each
            retailer sets availability, checkout and shipping; no payment is
            processed here.
          </p>
          <p className="cart-note">
            No combined checkout · No payment options · No live product listing
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
