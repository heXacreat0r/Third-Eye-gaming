import { AnimatePresence, motion } from "framer-motion";
import { useCart } from "@/contexts/CartContext";
import { CartDrawer } from "@/components/brand/CartDrawer";
import { SiteFooter } from "@/components/brand/SiteFooter";
import { SiteHeader } from "@/components/brand/SiteHeader";

type SiteLayoutProps = { children: React.ReactNode };

export function SiteLayout({ children }: SiteLayoutProps) {
  const cart = useCart();
  return (
    <div className="site-shell" id="top">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <SiteHeader itemCount={cart.count} onOpenCart={() => cart.setOpen(true)} />
      {children}
      <SiteFooter />
      <CartDrawer open={cart.open} onOpenChange={cart.setOpen} items={cart.items} onQuantityChange={cart.changeQuantity} onRemove={cart.remove} />
      <AnimatePresence>
        {cart.open && <motion.div className="cart-live-region" role="status" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>{cart.count ? `${cart.count} sample item${cart.count === 1 ? "" : "s"} in preview cart` : "Preview cart opened"}</motion.div>}
      </AnimatePresence>
    </div>
  );
}
