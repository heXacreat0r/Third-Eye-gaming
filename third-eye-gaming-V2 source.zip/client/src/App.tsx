import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CartProvider } from "@/contexts/CartContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { categories } from "@/data/homeContent";
import { categoryPaths, products } from "@/data/catalog";
import AboutPage from "@/pages/About";
import CategoryPage from "@/pages/Category";
import Home from "@/pages/Home";
import NotFound from "@/pages/NotFound";
import ProductPage from "@/pages/Product";
import ShopPage from "@/pages/Shop";
import SupportPage from "@/pages/Support";
import { Route, Switch, useLocation } from "wouter";
import { useEffect, useRef } from "react";
import ErrorBoundary from "./components/ErrorBoundary";

function Router() {
  const [location] = useLocation();
  const previous = useRef(location);
  useEffect(() => {
    if (previous.current === location) return;
    previous.current = location;
    window.scrollTo({ top: 0, behavior: "instant" });
    const main = document.getElementById("main-content");
    main?.setAttribute("tabindex", "-1");
    main?.focus({ preventScroll: true });
  }, [location]);
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/shop" component={ShopPage} />
      {categories.map(category => (
        <Route
          key={category.id}
          path={categoryPaths[category.id]}
          component={() => <CategoryPage categoryId={category.id} />}
        />
      ))}
      {products.map(product => (
        <Route
          key={product.id}
          path={`/products/${product.id}`}
          component={() => <ProductPage productId={product.id} />}
        />
      ))}
      <Route path="/about" component={AboutPage} />
      <Route path="/support" component={SupportPage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <CartProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </CartProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
