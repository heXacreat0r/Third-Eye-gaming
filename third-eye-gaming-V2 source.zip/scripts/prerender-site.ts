import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import {
  categories,
  pageCopy,
  stockAssets,
} from "../client/src/data/homeContent";
import {
  categoryPaths,
  formatINR,
  getProductsForCategory,
  getProductPath,
  products,
  retailers,
  type CategoryId,
} from "../client/src/data/catalog";

const output = path.resolve("dist/public");
const template = await readFile(path.join(output, "index.html"), "utf8");
const keywords =
  "Third Eye Gaming, gaming accessories, mouse accessories, keycaps, artisan keycaps, keycap keychains, mouse grips, mouse skates";
const shareImage = "/assets/third-eye-logo-light.png";
const escapeHtml = (value: string) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
const regexEscape = (value: string) =>
  value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

type Page = { path: string; title: string; description: string; body: string };
const pages: Page[] = [];

function productListMarkup(categoryId: CategoryId) {
  return getProductsForCategory(categoryId)
    .map(product => {
      const price = formatINR(product.price);
      return `<li><a href="${getProductPath(product)}">${escapeHtml(product.name)}</a> — ${escapeHtml(price)} sample price (illustrative)</li>`;
    })
    .join("");
}

const featuredProducts = products
  .filter(product => product.featured)
  .slice(0, 5);
pages.push({
  path: "/",
  title: "Third Eye Gaming — Accessories for Mouse & Keyboard Setups",
  description:
    "Thoughtful gaming accessories for mouse-and-keyboard setups. Explore keycaps, artisan keycaps, keycap keychains, mouse grips and mouse skates.",
  body: `<main id="main-content"><p>THIRD EYE GAMING / ACCESSORIES FOR YOUR SETUP</p><h1>The details that make a setup yours.</h1><p>A specialist accessories brand for mouse-and-keyboard setups, focused on considered design and comfort in the small details.</p><img src="${stockAssets.setup.src}" alt="${escapeHtml(stockAssets.setup.alt)}" width="720" height="900"><p>Illustrative stock photo by ${escapeHtml(stockAssets.setup.credit)}; not a Third Eye Gaming product.</p><h2>Featured accessories</h2><p>Sample names and INR prices are illustrative preview data, not final offers.</p><ul>${featuredProducts.map(product => `<li><a href="${getProductPath(product)}">${escapeHtml(product.name)}</a> — ${escapeHtml(formatINR(product.price))} sample price</li>`).join("")}</ul><h2>Five accessory categories</h2><ul>${categories.map(category => `<li><a href="${categoryPaths[category.id]}">${escapeHtml(category.name)}</a> — ${escapeHtml(category.description)}</li>`).join("")}</ul></main>`,
});

pages.push({
  path: "/shop",
  title: "Shop keyboard & mouse accessories | Third Eye Gaming",
  description:
    "Browse five gaming accessory categories for keyboard and mouse setups: keycaps, artisan keycaps, keycap keychains, mouse grips and mouse skates.",
  body: `<main id="main-content"><p>SHOP / ACCESSORIES</p><h1>Accessories for the setup you already own.</h1><p>Browse five touchpoints for mouse-and-keyboard setups. Sample names and INR prices are illustrative preview data.</p><ul>${categories.map(category => `<li><a href="${categoryPaths[category.id]}">${escapeHtml(category.name)}</a> — ${escapeHtml(category.description)} <ul>${productListMarkup(category.id)}</ul></li>`).join("")}</ul></main>`,
});

for (const category of categories) {
  const description = `${category.description} Browse sample ${category.name.toLowerCase()} preview items from Third Eye Gaming; product names and INR prices are illustrative.`;
  const items = getProductsForCategory(category.id);
  const viewerText =
    category.id === "mouse-grips" || category.id === "mouse-skates"
      ? "A third-party Superlight-shaped mouse model is available as a 360-degree reference viewer. It is not a Third Eye Gaming product. Reference dimensions are 125 × 63.5 × 40 mm; exact revision and fit must be validated."
      : category.id === "keycaps" || category.id === "artisan-keycaps"
        ? "A third-party generic keyboard model is available as an interactive visual reference. It is not a Third Eye Gaming product or final product CAD."
        : "The category visual is an abstract graphic, not a product image.";
  pages.push({
    path: categoryPaths[category.id],
    title: `${category.name} accessories | Third Eye Gaming`,
    description,
    body: `<main id="main-content"><p>${escapeHtml(category.number)} / ${escapeHtml(category.eyebrow)}</p><h1>${escapeHtml(category.name)}.</h1><p>${escapeHtml(category.description)}</p><h2>Featured in ${escapeHtml(category.name.toLowerCase())}</h2><p>Sample product names and INR prices are illustrative. Materials, compatibility and final product photography are pending.</p><ul>${productListMarkup(category.id)}</ul><p>${escapeHtml(viewerText)}</p><p>Stock imagery and licensed 3D references are illustrative only, not Third Eye Gaming products.</p></main>`,
  });
}

for (const product of products) {
  const category = categories.find(item => item.id === product.categoryId)!;
  const description = `${product.name}: ${product.description} An illustrative sample product page with preview pricing from Third Eye Gaming.`;
  const modelText =
    product.detailModel === "mouse"
      ? "Rotate the licensed Superlight-shaped mouse reference. Dimensions: 125 × 63.5 × 40 mm as a fitment reference only; final fitment is not verified."
      : product.detailModel === "keyboard"
        ? "Rotate the licensed generic keyboard reference. It is not a Third Eye Gaming product or final product CAD."
        : "The graphic is an abstract category marker, not a product rendering.";
  pages.push({
    path: getProductPath(product),
    title: `${product.name} — ${category.name} preview | Third Eye Gaming`,
    description,
    body: `<main id="main-content"><p>${escapeHtml(category.name.toUpperCase())} / PREVIEW</p><h1>${escapeHtml(product.name)}</h1><p>${escapeHtml(product.description)}</p><p>${escapeHtml(formatINR(product.price))} sample price · INR · illustrative only</p><p>Sample name, price and media; not a final product listing or offer.</p><p>${escapeHtml(modelText)}</p><p>Retailer homepages (not product-specific listings): ${retailers.map(retailer => `<a href="${retailer.href}">${escapeHtml(retailer.name)}</a>`).join(" and ")}.</p><p>No payment is processed here.</p></main>`,
  });
}

pages.push({
  path: "/about",
  title: "About Third Eye Gaming — the details that matter",
  description:
    "Learn about Third Eye Gaming, an accessories brand for mouse-and-keyboard setups focused on design, comfort and the small details that matter.",
  body: '<main id="main-content"><p>ABOUT / OUR POINT OF VIEW</p><h1>A different kind of gaming brand.</h1><p>Third Eye Gaming is a specialist accessories brand for mouse-and-keyboard setups, not a whole-peripheral brand.</p><h2>Open another dimension for your gaming setup.</h2><p>The name is about seeing a setup differently: noticing the small details that matter in daily use and giving them more intention.</p><p>The brand stands for luxury and comfort in the small details and can manufacture accessories for other brands.</p></main>',
});

pages.push({
  path: "/support",
  title: "Support & shipping policies | Third Eye Gaming",
  description:
    "Current shipping and return-period information for Third Eye Gaming. Final policy conditions and customer-support contact details are pending confirmation.",
  body: '<main id="main-content"><p>SUPPORT / INFORMATION</p><h1>Clear answers, as they become final.</h1><h2>Where will Third Eye Gaming ship?</h2><p>The current plan is shipping across India.</p><h2>When are shipping charges shown?</h2><p>Shipping costs are added at checkout. Third-party retailer destinations shown are general homepages and each retailer controls its own checkout and shipping terms.</p><h2>What is the return period?</h2><p>The current stated return period is one month. Eligibility, process, exclusions and refund timing are pending confirmation.</p><h2>Contact</h2><p>Customer-support contact details have not been supplied.</p></main>',
});

function upsertMeta(
  html: string,
  key: string,
  value: string,
  attribute: "name" | "property" = "name"
) {
  const tag = `<meta ${attribute}="${escapeHtml(key)}" content="${escapeHtml(value)}" />`;
  const matcher = new RegExp(
    `<meta\\s+${attribute}=["']${regexEscape(key)}["'][^>]*\\/?\\s*>`,
    "i"
  );
  return matcher.test(html)
    ? html.replace(matcher, tag)
    : html.replace("</head>", `  ${tag}\n  </head>`);
}

for (const page of pages) {
  if (page.path === "/") {
    page.body = page.body.replace(
      "<h2>Featured accessories</h2>",
      `<section aria-label="Our vision"><h2>${escapeHtml(pageCopy.visionTitle)}</h2><p>${escapeHtml(pageCopy.visionDescription)}</p></section><h2>Featured accessories</h2>`
    );
  }
  let html = template.replace(
    /<title>[\s\S]*?<\/title>/i,
    `<title>${escapeHtml(page.title)}</title>`
  );
  html = upsertMeta(html, "description", page.description);
  html = upsertMeta(html, "keywords", keywords);
  html = upsertMeta(html, "og:type", "website", "property");
  html = upsertMeta(html, "og:site_name", "Third Eye Gaming", "property");
  html = upsertMeta(html, "og:title", page.title, "property");
  html = upsertMeta(html, "og:description", page.description, "property");
  html = upsertMeta(html, "og:image", shareImage, "property");
  html = upsertMeta(
    html,
    "og:image:alt",
    "Temporary Third Eye Gaming wordmark",
    "property"
  );
  html = upsertMeta(html, "twitter:card", "summary");
  html = upsertMeta(html, "twitter:title", page.title);
  html = upsertMeta(html, "twitter:description", page.description);
  html = upsertMeta(html, "twitter:image", shareImage);
  html = upsertMeta(
    html,
    "twitter:image:alt",
    "Temporary Third Eye Gaming wordmark"
  );
  html = html.replace(
    /(<div id="root">)[\s\S]*?(<\/div>)/i,
    `$1${page.body}$2`
  );
  const folder = path.join(output, page.path.replace(/^\//, ""));
  await mkdir(folder, { recursive: true });
  await writeFile(path.join(folder, "index.html"), html, "utf8");
}

console.log(
  `Prerendered ${pages.length} routes: ${pages.map(page => page.path).join(", ")}`
);
