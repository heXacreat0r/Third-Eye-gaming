import assert from "node:assert/strict";
const base = process.env.TEST_ORIGIN || "http://localhost:3000";
const paths = [
  "/",
  "/shop",
  "/about",
  "/support",
  "/categories/keycaps",
  "/categories/artisan-keycaps",
  "/categories/keycap-keychains",
  "/categories/mouse-grips",
  "/categories/mouse-skates",
  "/products/keycap-01",
  "/products/keycap-02",
  "/products/artisan-01",
  "/products/artisan-02",
  "/products/keychain-01",
  "/products/keychain-02",
  "/products/grip-01",
  "/products/grip-02",
  "/products/skates-01",
  "/products/skates-02",
];
for (const route of paths) {
  const res = await fetch(base + route);
  assert.equal(res.status, 200, route);
  assert.match(res.headers.get("content-type"), /text\/html/);
}
for (const asset of [
  "third-eye-logo-light.png",
  "third-eye-logo-dark.png",
  "home-setup-stock.webp",
  "keyboard-closeup-stock.webp",
  "mouse-closeup-stock.webp",
]) {
  const res = await fetch(`${base}/assets/${asset}`);
  assert.equal(res.status, 200, asset);
  assert.match(res.headers.get("content-type"), /^image\//);
}
for (const route of [
  "/missing-route",
  "/404",
  "/assets/missing.png",
  "/__manus__/debug-collector.js",
  "/api/unknown",
]) {
  assert.equal((await fetch(base + route)).status, 404, route);
}
const home = await fetch(base);
const html = await home.text();
assert.equal(home.headers.get("x-content-type-options"), "nosniff");
assert.equal(home.headers.get("x-powered-by"), null);
const csp = home.headers.get("content-security-policy");
assert.match(csp, /script-src 'self' 'sha256-/);
assert.doesNotMatch(csp, /unsafe-eval/);
assert.doesNotMatch(html, /debug-collector/);
const blocked = await fetch(`${base}/api/trpc/auth.logout`, {
  method: "POST",
  headers: {
    Origin: "https://attacker.example",
    "Content-Type": "application/json",
  },
  body: "{}",
});
assert.equal(blocked.status, 403);
const oversized = await fetch(`${base}/api/trpc/auth.logout`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ value: "a".repeat(70_000) }),
});
assert.equal(oversized.status, 413);
assert.deepEqual(await oversized.json(), { error: "Request too large" });
const disabledLogin = await fetch(`${base}/api/oauth/callback`);
assert.equal(disabledLogin.status, 503);
console.log(
  `PASS: ${paths.length} page routes, 5 images, 5 missing/debug/API routes; CSP, header privacy, CSRF, body limit and unconfigured login.`
);
