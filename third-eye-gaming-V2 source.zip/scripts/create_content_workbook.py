from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

OUT = Path('/home/ubuntu/thirdeye/deliverables/third-eye-gaming-website-copy.xlsx')
OUT.parent.mkdir(parents=True, exist_ok=True)

INK, PORCELAIN, ORANGE = '171615', 'F2EEE7', 'E45C32'
GRAPHITE, ASH, PALE = '383532', 'B9B1A7', 'E9E3D9'
LINE, WHITE = 'D6CEC4', 'FFFFFF'
DRAFT, PENDING, FACT, SAMPLE = 'F8E1D7', 'F1EBD9', 'E2ECE2', 'FCE8B9'
thin = Side(style='thin', color=LINE)


def setup_sheet(ws, title, description, headers, widths, tab_color=ORANGE):
    last_col = get_column_letter(len(headers))
    ws.merge_cells(f'A1:{last_col}1')
    ws['A1'] = title
    ws['A1'].fill = PatternFill('solid', fgColor=INK)
    ws['A1'].font = Font(name='Arial', size=16, bold=True, color=PORCELAIN)
    ws['A1'].alignment = Alignment(vertical='center')
    ws.row_dimensions[1].height = 31
    ws.merge_cells(f'A2:{last_col}2')
    ws['A2'] = description
    ws['A2'].fill = PatternFill('solid', fgColor=PALE)
    ws['A2'].font = Font(name='Arial', size=10, color=GRAPHITE, italic=True)
    ws['A2'].alignment = Alignment(wrap_text=True, vertical='center')
    ws.row_dimensions[2].height = 38
    ws.row_dimensions[3].height = 8
    for col, header in enumerate(headers, start=1):
        cell = ws.cell(row=4, column=col, value=header)
        cell.fill = PatternFill('solid', fgColor=ORANGE)
        cell.font = Font(name='Arial', size=10, bold=True, color=INK)
        cell.alignment = Alignment(wrap_text=True, vertical='center')
        cell.border = Border(bottom=Side(style='medium', color=INK))
        ws.column_dimensions[get_column_letter(col)].width = widths[col - 1]
    ws.row_dimensions[4].height = 32
    ws.freeze_panes = 'A5'
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = tab_color
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = 0.25
    ws.page_margins.right = 0.25
    ws.page_margins.top = 0.45
    ws.page_margins.bottom = 0.45


def populate(ws, rows, status_col=None):
    for row_index, row in enumerate(rows, start=5):
        max_lines = 1
        for col_index, value in enumerate(row, start=1):
            cell = ws.cell(row=row_index, column=col_index, value=value)
            cell.font = Font(name='Arial', size=10, color=INK)
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            cell.border = Border(bottom=thin)
            if row_index % 2 == 0:
                cell.fill = PatternFill('solid', fgColor='FBF9F4')
            if isinstance(value, str) and value.startswith('https://'):
                cell.hyperlink = value
                cell.font = Font(name='Arial', size=9, color='6B4836', underline='single')
            if isinstance(value, str):
                width = ws.column_dimensions[get_column_letter(col_index)].width or 16
                max_lines = max(max_lines, min(6, len(value) // max(18, int(width * 1.35)) + 1))
        ws.row_dimensions[row_index].height = max(38, min(108, max_lines * 15 + 12))
        if status_col:
            status_cell = ws.cell(row=row_index, column=status_col)
            status = str(status_cell.value or '').upper()
            fill = FACT if 'USER-SUPPLIED FACT' in status or status == 'FACT' else SAMPLE if 'SAMPLE' in status else DRAFT if 'DRAFT' in status or 'REVIEW' in status else PENDING
            status_cell.fill = PatternFill('solid', fgColor=fill)
            status_cell.font = Font(name='Arial', size=9, bold=True, color=INK)
    ws.auto_filter.ref = f'A4:{get_column_letter(ws.max_column)}{ws.max_row}'
    ws.print_title_rows = '1:4'


wb = Workbook()
wb.remove(wb.active)
wb.properties.title = 'Third Eye Gaming — Website Copy & Content Inputs'
wb.properties.subject = 'Draft copy for all V1 routes, sample catalogue and asset/model source register'
wb.properties.creator = 'Third Eye Gaming website project'

# A concise guide sheet makes sample/final status explicit for investor sharing.
ws = wb.create_sheet('Read me')
readme_rows = [
    ('Brand', 'Third Eye Gaming', 'USER-SUPPLIED FACT', 'The temporary logo is used in theme-matched light/dark variants.'),
    ('Positioning', 'Specialist gaming peripheral accessories brand; not a complete-peripherals brand.', 'USER-SUPPLIED FACT', 'The brand sells under Third Eye Gaming and can manufacture accessories for other brands.'),
    ('Brand meaning', 'Open another dimension for your gaming setup.', 'USER-SUPPLIED FACT', 'Meaning supplied by the owner. No separate brand tagline has been proposed.'),
    ('Audience', 'Anyone who owns a mouse and keyboard; India is the primary region.', 'USER-SUPPLIED FACT', 'Includes gaming, casual and office use cases.'),
    ('Colors', 'Ink #171615 · Porcelain #F2EEE7 · Orange #E45C32 · Graphite #383532 · Ash #B9B1A7', 'APPROVED DESIGN', 'Light/dark modes use same palette with contrast-adjusted text/surfaces.'),
    ('Sample names/prices', 'All 10 product names and INR amounts are illustrative preview data.', 'SAMPLE — NOT FINAL', 'Owner authorized working/sample names and stock prices for V1; all rows stay visibly labeled sample.'),
    ('Featured language', 'Use “Featured”; do not claim “Best Seller.”', 'USER-SUPPLIED DIRECTION', 'No sales-ranking data was supplied.'),
    ('3D models', 'Generic CC BY 4.0 Sketchfab reference models, not Third Eye Gaming products or final CAD.', 'REFERENCE ONLY', 'Creators/source/license are listed in Assets & sources. If an embed fails, open its source page.'),
    ('Superlight dimensions', '125 × 63.5 × 40 mm', 'REFERENCE ONLY', 'Third-party product comparison; verify hardware revision and fit before manufacture.'),
    ('Retailer links', 'Meckeys and Genesis PC homepages only; no product-specific listing URLs supplied.', 'USER-APPROVED GENERAL DESTINATIONS', 'No combined checkout or payment method is implemented.'),
    ('Shipping', 'Plan is shipping across India; shipping costs are added at checkout.', 'USER-SUPPLIED FACT', 'Final fulfillment wording and retailer-specific application remain to confirm.'),
    ('Returns', 'One-month return period stated.', 'USER-SUPPLIED FACT', 'Eligibility, process, exclusions and refund timing were not supplied.'),
    ('Contact details', 'No support email, phone, address or social account was supplied.', 'PENDING OWNER INPUT', 'The site says this plainly rather than inventing contact details.'),
    ('Draft copy', 'All headlines, section descriptions and SEO copy in Website copy require owner review.', 'DRAFT — REVIEW', 'No line should be treated as an approved brand tagline.'),
]
setup_sheet(ws, 'Third Eye Gaming | Content workbook guide', 'Draft copy, approved facts and illustrative values for the current website V1. Review statuses are carried in every sheet.', ['Topic', 'Current value', 'Status', 'Notes'], [24, 72, 34, 62], GRAPHITE)
populate(ws, readme_rows, status_col=3)

categories = [
    ('keycaps', 'Keycaps', 'A new touchpoint for the keyboard already on your desk.', '#E45C32', 'Keycap 1', 1299, 'A considered touchpoint for the mechanical keyboard already on your desk.', 'keyboard-photo', True),
    ('keycaps', 'Keycaps', 'A new touchpoint for the keyboard already on your desk.', '#E45C32', 'Keycap 2', 1499, 'A second sample direction for a setup shaped around your own taste.', 'keyboard-photo', False),
    ('artisan-keycaps', 'Artisan keycaps', 'Single-key details with room for personality.', '#964633', 'Artisan 1', 699, 'One expressive accent for the key you reach for most.', 'keyboard-photo', True),
    ('artisan-keycaps', 'Artisan keycaps', 'Single-key details with room for personality.', '#964633', 'Artisan 2', 799, 'A small sculptural detail in a keyboard-first setup.', 'keyboard-photo', False),
    ('keycap-keychains', 'Keycap keychains', 'Keyboard-inspired details to carry with you.', '#87572D', 'Keycap Keychain 1', 399, 'A keyboard-inspired detail to take beyond the desk.', 'keychain-abstract', True),
    ('keycap-keychains', 'Keycap keychains', 'Keyboard-inspired details to carry with you.', '#87572D', 'Keycap Keychain 2', 499, 'A second sample take on a familiar key, made portable.', 'keychain-abstract', False),
    ('mouse-grips', 'Mouse grips', 'A tactile detail for how your mouse meets your hand.', '#58665A', 'Grip Set 1', 599, 'A sample tactile detail shown with the Superlight fit-reference mouse.', 'mouse-photo', True),
    ('mouse-grips', 'Mouse grips', 'A tactile detail for how your mouse meets your hand.', '#58665A', 'Grip Set 2', 699, 'An alternate sample direction for a mouse-accessory setup.', 'mouse-photo', False),
    ('mouse-skates', 'Mouse skates', 'Small details for the way a mouse moves.', '#586467', 'Skate Set 1', 499, 'A sample mouse-movement accessory shown beside the Superlight reference model.', 'mouse-photo', True),
    ('mouse-skates', 'Mouse skates', 'Small details for the way a mouse moves.', '#586467', 'Skate Set 2', 599, 'A second illustrative option for the mouse-skates category.', 'mouse-photo', False),
]

# Every customer-facing string is intentionally reviewable and marked as a draft.
copy_rows = []
def add_copy(page, section, field, text, status='DRAFT — REVIEW', note='Draft copy; not an approved tagline.'):
    copy_rows.append((page, section, field, text, status, note))

add_copy('Home', 'SEO', 'Page title', 'Third Eye Gaming — Accessories for Mouse & Keyboard Setups', note='Title is not a brand tagline; no canonical domain configured.')
add_copy('Home', 'SEO', 'Meta description', 'Thoughtful gaming accessories for mouse-and-keyboard setups. Explore keycaps, artisan keycaps, keycap keychains, mouse grips and mouse skates.', note='Draft description; includes all five supplied categories.')
add_copy('Home', 'SEO', 'Keywords', 'Third Eye Gaming, gaming accessories, mouse accessories, keycaps, artisan keycaps, keycap keychains, mouse grips, mouse skates', note='Eight terms; review for preferred search language.')
add_copy('Shared navigation', 'Mega menu', 'Menu title and intro', 'Choose your touchpoint. Accessories for the keyboard and mouse already in your setup.', note='Interaction copy, user review requested.')
add_copy('Shared navigation', 'Mega menu', 'Primary links', 'Home · Shop · Keycaps · Artisan keycaps · Keycap keychains · Mouse grips · Mouse skates · About · Support · Cart', note='Route set mirrors the implementation.')
add_copy('Home', 'Hero', 'Eyebrow', 'THIRD EYE GAMING / ACCESSORIES FOR YOUR SETUP', note='Homepage label, not a tagline.')
add_copy('Home', 'Hero', 'Headline', 'The details that make a setup yours.', note='Draft page headline, not an approved tagline.')
add_copy('Home', 'Hero', 'Description', 'A specialist accessories brand for mouse-and-keyboard setups, focused on considered design and comfort in the small details.', note='Based on supplied positioning; review wording.')
add_copy('Home', 'Hero', 'Primary CTA', 'Explore accessories', note='Links to Shop.')
add_copy('Home', 'Hero', 'Secondary CTA', 'A different kind of brand', note='Links to About.')
add_copy('Home', 'Hero image', 'Visible caption', 'Illustrative stock photo; not a Third Eye Gaming product.', note='Image credit: Jeremy Rorimpandey / Unsplash.')
add_copy('Home', 'Featured accessories', 'Section heading', 'Featured accessories', note='Explicitly uses “Featured”; no sales ranking is claimed.')
add_copy('Home', 'Featured accessories', 'Section description', 'A considered first look across keycaps, artisan keycaps, keycap keychains, mouse grips and mouse skates. Names and prices in this preview are illustrative.', note='Sample data is visible and also flagged on each item.')
add_copy('Home', 'Scroll lens', 'Section heading', 'A closer look, in motion.', note='Inspired by the supplied MacBook Scroll interaction reference; the site uses a keyboard stock photo.')
add_copy('Home', 'Scroll lens', 'Section description', 'Start with the whole setup. Scroll closer to the small details that shape how it feels.', note='Scroll-driven zoom reveals a stock keyboard image; not an actual product visual.')
add_copy('Home', 'Scroll lens', 'Image disclosure', 'STOCK PHOTO · NOT A THIRD EYE GAMING PRODUCT', note='Visible disclosure stays over the image.')
add_copy('Home', 'Category flow', 'Section heading', 'Move through the details.', note='Five cards link to individual category pages in a horizontal perspective flow.')
add_copy('Home', 'Category flow', 'Section description', 'From the keys beneath your fingers to the mouse in your hand, explore each part of the setup.', note='Draft section copy.')
add_copy('Home', 'Brand', 'Section heading', 'We make accessories, not another keyboard or mouse.', note='Draft positioning; not an approved tagline.')
add_copy('Home', 'Brand', 'Description', 'Third Eye Gaming is a specialist gaming-accessories brand for mouse-and-keyboard setups. The point of view is quiet luxury in the details: thoughtful design, comfort, and the small things that matter.', note='Based on owner-supplied facts; review final voice.')
add_copy('Home', 'Closing', 'Headline', 'The setup is yours. Make the details count.', note='Draft closing headline, not an approved tagline.')
add_copy('Home', 'Closing', 'CTA', 'Explore the categories', note='Links to Shop.')

category_titles = {
    'Keycaps': 'Keycap accessories | Third Eye Gaming',
    'Artisan keycaps': 'Artisan keycap accessories | Third Eye Gaming',
    'Keycap keychains': 'Keycap keychains | Third Eye Gaming',
    'Mouse grips': 'Mouse grips | Third Eye Gaming',
    'Mouse skates': 'Mouse skates | Third Eye Gaming',
}
for category_id, name, description, accent, sample_name, price, product_description, visual, featured in categories:
    add_copy(f'Category / {name}', 'SEO', 'Page title', category_titles[name], note=f'Category route: /categories/{category_id}.')
    add_copy(f'Category / {name}', 'Hero', 'Description', description, note='Draft description based on the supplied category name.')
    add_copy(f'Category / {name}', 'Product grid', 'Heading and status', f'Featured in {name.lower()}. Product names and prices are illustrative; materials, compatibility and actual product photography are pending.', note='No performance/specification claim is made.')
    add_copy(f'Category / {name}', 'Media', 'Disclosure', 'Illustrative stock photos and licensed 3D references are not Third Eye Gaming products.', note='Actual product imagery is not supplied.')
    if name in ('Keycaps', 'Artisan keycaps'):
        add_copy(f'Category / {name}', '3D viewer', 'Disclosure', 'Generic licensed keyboard reference, not a Third Eye Gaming keycap set or final product CAD.', note='CC BY 4.0 creator/source/license shown beside the embedded viewer.')
    if name in ('Mouse grips', 'Mouse skates'):
        add_copy(f'Category / {name}', '3D viewer', 'Disclosure', 'Superlight-shaped mouse model is a third-party reference; fitment is not verified.', note='Dimensions are a reference only; exact mouse revision must be checked.')
    if name == 'Keycap keychains':
        add_copy(f'Category / {name}', 'Category graphic', 'Disclosure', 'Abstract category marker only; not a product rendering.', note='CSS artwork, no invented product image.')

for category_id, name, description, accent, sample_name, price, product_description, visual, featured in categories:
    product_id = sample_name.lower().replace(' ', '-')
    add_copy(f'Product / {sample_name}', 'SEO', 'Page title', f'{sample_name} — {name} preview | Third Eye Gaming', note=f'Route uses sample ID {product_id}; product names remain illustrative.')
    add_copy(f'Product / {sample_name}', 'Product detail', 'Name', sample_name, 'SAMPLE — NOT FINAL', 'Owner-authorized working sample name; replace after final catalogue is provided.')
    add_copy(f'Product / {sample_name}', 'Product detail', 'Description', product_description, note='Draft, non-specific description; review before use as product copy.')
    add_copy(f'Product / {sample_name}', 'Product detail', 'Sample price', f'₹{price:,} INR', 'SAMPLE — NOT FINAL', 'Illustrative price authorized for preview only; not a live offer.')
    add_copy(f'Product / {sample_name}', 'Product detail', 'Media and fitment disclosure', 'Stock image / abstract visual / generic 3D reference. Not a Third Eye Gaming product; materials, specifications and compatibility are unverified.', note='Exact visible text varies by the media on the page.')
    add_copy(f'Product / {sample_name}', 'Retailer handoff', 'Link status', 'Meckeys and Genesis PC homepage links only; no product-specific listing or availability claim.', 'USER-APPROVED GENERAL DESTINATION', 'No first-party checkout or payment is implemented.')

add_copy('About', 'SEO', 'Page title', 'About Third Eye Gaming — the details that matter', note='Draft title.')
add_copy('About', 'Hero', 'Headline', 'A different kind of gaming brand.', note='Draft headline.')
add_copy('About', 'Name', 'Meaning', 'Open another dimension for your gaming setup.', 'USER-SUPPLIED FACT', 'Meaning supplied by owner; no tagline is being proposed.')
add_copy('About', 'Positioning', 'Description', 'Third Eye Gaming makes accessories for the mouse-and-keyboard setup you already own—not another complete peripheral line.', note='Draft wording of owner-supplied distinction.')
add_copy('About', 'OEM', 'Manufacturing', 'Third Eye Gaming can manufacture accessories for other brands.', 'USER-SUPPLIED FACT', 'Business capability supplied by owner.')
add_copy('Support', 'SEO', 'Page title', 'Support & shipping policies | Third Eye Gaming', note='Draft title.')
add_copy('Support', 'Shipping', 'Coverage', 'The current plan is to ship across India.', 'USER-SUPPLIED FACT', 'Exact fulfillment terms not supplied.')
add_copy('Support', 'Shipping charges', 'Checkout', 'Shipping costs are added at checkout; each retailer controls its own checkout and shipping terms.', 'USER-SUPPLIED FACT', 'Retailer-specific application remains to confirm.')
add_copy('Support', 'Returns', 'Return period', 'One-month return period.', 'USER-SUPPLIED FACT', 'Eligibility, process, exclusions and refund timing not supplied.')
add_copy('Support', 'Contact', 'Support channel', 'Support contact details have not been supplied.', 'PENDING OWNER INPUT', 'Do not invent an email, phone number or social account.')
add_copy('Cart', 'Cart', 'Summary', 'Working preview cart with add, remove, quantity and illustrative subtotal; no payment is processed here.', note='Retailer links are separate general homepages; no combined checkout.')
add_copy('Footer', 'Retailers', 'Link note', 'Meckeys and Genesis PC are general retailer homepages, not product-specific Third Eye Gaming listings.', 'USER-APPROVED GENERAL DESTINATION', 'Owner said product-specific URLs are not required for this preview.')

ws = wb.create_sheet('Website copy')
setup_sheet(ws, 'Third Eye Gaming | Website copy', 'Draft and user-supplied copy for the live route set. Review status is explicit; no draft headline is an approved brand tagline.', ['Page / route', 'Section', 'Content field', 'Draft copy / value', 'Status', 'Notes / source'], [28, 23, 27, 80, 31, 56], ORANGE)
populate(ws, copy_rows, status_col=5)

product_rows = []
sample_route_ids = {
    'Keycap 1': 'keycap-01', 'Keycap 2': 'keycap-02',
    'Artisan 1': 'artisan-01', 'Artisan 2': 'artisan-02',
    'Keycap Keychain 1': 'keychain-01', 'Keycap Keychain 2': 'keychain-02',
    'Grip Set 1': 'grip-01', 'Grip Set 2': 'grip-02',
    'Skate Set 1': 'skates-01', 'Skate Set 2': 'skates-02',
}
for category_id, name, description, accent, sample_name, price, product_description, visual, featured in categories:
    product_rows.append((category_id, name, sample_name, f'₹{price:,}', 'SAMPLE — illustrative only', product_description, 'Pending final SKU / name', 'Pending specifications', 'Pending material', 'Pending variants', 'Pending exact fitment', 'Pending actual product photo', f'/products/{sample_route_ids[sample_name]}', 'Featured' if featured else 'Standard preview', 'No live retailer listing; general homepage links only.'))
ws = wb.create_sheet('Sample products')
setup_sheet(ws, 'Illustrative sample catalogue', 'Owner-authorized working sample names and stock INR prices for the investor preview. These are not finalized SKUs, prices, offers or live listings.', ['Category ID', 'Category', 'Sample name', 'Sample price (INR)', 'Price status', 'Draft description', 'Final product name / SKU', 'Specifications', 'Materials', 'Variants / colorways', 'Compatibility / fit', 'Actual product image', 'Preview route', 'Showcase status', 'Retailer listing status'], [22, 23, 24, 20, 29, 54, 30, 30, 22, 25, 28, 32, 30, 22, 43], GRAPHITE)
populate(ws, product_rows, status_col=5)

owner_rows = [
    ('Brand name', 'Third Eye Gaming', 'USER-SUPPLIED FACT', 'Temporary logo provided.'),
    ('Brand meaning', 'Open another dimension for your gaming setup.', 'USER-SUPPLIED FACT', 'Meaning only; no tagline supplied.'),
    ('Brand role', 'Specialist gaming peripheral accessories brand; sells under Third Eye Gaming and can manufacture for other brands.', 'USER-SUPPLIED FACT', 'Not a complete peripherals brand.'),
    ('Target / region', 'Anyone who owns a mouse and keyboard; primary market India.', 'USER-SUPPLIED FACT', 'User also described casual, fun, office and gaming use cases.'),
    ('Shipping coverage', 'Across India.', 'USER-SUPPLIED FACT', 'Full fulfillment terms not supplied.'),
    ('Shipping charges', 'Added at checkout.', 'USER-SUPPLIED FACT', 'Confirm how this applies where a visitor follows a third-party retailer link.'),
    ('Return period', 'One month.', 'USER-SUPPLIED FACT', 'Eligibility, process, exclusions and refund timing remain to confirm.'),
    ('Final SKU list', 'Awaiting finalized product list.', 'PENDING OWNER INPUT', 'Needed to replace sample names and sample copy.'),
    ('Materials / specs', 'Awaiting product-by-product data.', 'PENDING OWNER INPUT', 'Do not invent materials, specifications, compatibility or product claims.'),
    ('Final INR prices', 'Awaiting finalized product list and prices.', 'PENDING OWNER INPUT', 'Preview includes clearly marked owner-authorized sample prices only.'),
    ('Product photos / CAD', 'Awaiting actual product photography or final product 3D models.', 'PENDING OWNER INPUT', 'Stock photos and CC BY models are clearly disclosed as illustrative references.'),
    ('Retailer homepage: Meckeys', 'https://meckeys.com/', 'USER-APPROVED GENERAL DESTINATION', 'General homepage; no product-specific Third Eye listing was supplied.'),
    ('Retailer homepage: Genesis PC', 'https://www.genesispc.in/', 'USER-APPROVED GENERAL DESTINATION', 'General homepage; no product-specific Third Eye listing was supplied.'),
    ('Support email / phone / social', 'Not supplied.', 'PENDING OWNER INPUT', 'Website states details have not been supplied; no contact is fabricated.'),
]
ws = wb.create_sheet('Owner inputs')
setup_sheet(ws, 'Owner inputs & policy facts', 'Supplied business facts are separated from missing final product data and policy conditions.', ['Input', 'Current value', 'Status', 'Notes / next action'], [30, 68, 35, 64], ASH)
populate(ws, owner_rows, status_col=3)

asset_rows = [
    ('Home setup photograph', 'Jeremy Rorimpandey / Unsplash', 'https://unsplash.com/photos/mechanical-keyboard-and-mouse-on-a-desk-with-plants-rW2KRSx2vJs', 'Home hero / setup context', '3000 × 4500 px source; display crop 0.84:1', 'Illustrative stock photo; not a Third Eye Gaming product. Caption and alt disclose.', '/manus-storage/home-setup-stock_88509dd3.webp'),
    ('Keyboard close-up photograph', 'Almas Salakhov / Unsplash', 'https://unsplash.com/photos/a-close-up-of-a-computer-keyboard-8hTqBs8N4f0', 'Home scroll zoom, keycap product cards and page context', '3000 × 3996 px source; display crops vary', 'Illustrative stock photo; not Third Eye Gaming keycaps/keyboard. Caption and alt disclose.', '/manus-storage/keyboard-closeup-stock_cfe08e4e.webp'),
    ('Mouse close-up photograph', 'Haberdoedas / Unsplash', 'https://unsplash.com/photos/black-computer-mouse-with-scroll-wheel-resting-on-wood-DXFWA-jLrcc', 'Mouse category/product page context', '3000 × 2250 px source; display crops vary', 'Illustrative stock photo; not a Third Eye Gaming mouse, grip or skate.', '/manus-storage/mouse-closeup-stock_68ea509c.webp'),
    ('Temporary wordmark / light mode', 'User-supplied logo attachment', 'User attachment', 'Header and footer on light surfaces', '1140 × 320 px transparent PNG', 'Ink/Orange derivative; original temporary brand mark/wordmark preserved.', '/manus-storage/third-eye-logo-light_bc9f7ba7.png'),
    ('Temporary wordmark / dark mode', 'User-supplied logo attachment', 'User attachment', 'Header and footer on dark surfaces', '1140 × 320 px transparent PNG', 'Porcelain/Orange derivative; original temporary brand mark/wordmark preserved.', '/manus-storage/third-eye-logo-dark_288a8fb3.png'),
    ('Generic keyboard 3D reference', 'unknown.fbx / ibrahimtaha.fbx, Sketchfab', 'https://sketchfab.com/3d-models/custom-mechanical-keyboard-90d61eec0c484332ab562c5f4eda6f52', 'Keyboard and keycap interactive viewer; rotate/zoom', 'Hosted Sketchfab iframe; 3D dimensions not used as product specs', 'CC BY 4.0; visibly attributed. Generic model, not Third Eye product/CAD. NoAI terms respected: no AI training/generation.', 'Model UID 90d61eec0c484332ab562c5f4eda6f52'),
    ('Superlight-shaped mouse 3D reference', 'zhe_kan, Sketchfab', 'https://sketchfab.com/3d-models/computer-mouse-6e7940d9e2144efeae3468a906f27e07', 'Mouse grip/skate interactive 360° reference viewer', 'Hosted Sketchfab iframe; fit reference 125 × 63.5 × 40 mm', 'CC BY 4.0; visibly attributed. Reference model only, not Third Eye product. Validate exact revision/fit before manufacturing.', 'Model UID 6e7940d9e2144efeae3468a906f27e07'),
    ('Superlight dimensions source', 'B&H Photo Video comparison table', 'https://www.bhphotovideo.com/c/compare/Logitech+G_Pro+X+Superlight+2_vs_Logitech+G_PRO+X+SUPERLIGHT/BHitems/1785646-REG_1609024-REG', 'Mouse fitment reference only', '125 × 63.5 × 40 mm', 'Dimension applies to both models in the source table. Not a Third Eye product spec; exact revision/fit must be verified.', 'Source only; no copied image/model'),
    ('Meckeys retailer homepage', 'Meckeys', 'https://meckeys.com/', 'General retailer destination on product pages/cart/footer', 'External home page', 'User-approved general homepage; no product-specific listings claimed.', 'Retailer link'),
    ('Genesis PC retailer homepage', 'Genesis PC', 'https://www.genesispc.in/', 'General retailer destination on product pages/cart/footer', 'External home page', 'User-approved general homepage; no product-specific listings claimed.', 'Retailer link'),
    ('MacBook Scroll UI reference', 'Aceternity UI', 'https://ui.aceternity.com/components/macbook-scroll', 'Home scroll-driven photo zoom behavior', 'Interaction reference only', 'Do not copy its design/visual identity.', 'User-provided component reference'),
    ('Text Hover UI reference', 'Aceternity UI', 'https://ui.aceternity.com/components/text-hover-effect', 'Logo hover sweep', 'Interaction reference only', 'Keep logo readable/accessibility text intact.', 'User-provided component reference'),
    ('Comet Card UI reference', 'Aceternity UI', 'https://ui.aceternity.com/components/comet-card', 'Product detail perspective/hover motion', 'Interaction reference only', 'Use behavior idea; do not copy its styling wholesale.', 'User-provided component reference'),
    ('Mega Navbar UI reference', 'Aceternity UI', 'https://ui.aceternity.com/blocks/navbars/navbar-mega', 'Grouped, responsive navigation behavior', 'Interaction reference only', 'Adapt to Third Eye category set; no source code copied wholesale.', 'User-provided component reference'),
]
ws = wb.create_sheet('Assets & sources')
setup_sheet(ws, 'Asset, model and reference register', 'Photographic provenance, 3D licenses/attribution, fit-reference dimensions and user-provided interaction references.', ['Asset / reference', 'Creator / source', 'Verified source / license page', 'Website use', 'Dimensions / display', 'Status, license and disclosure', 'Managed path / identifier'], [34, 32, 76, 40, 39, 74, 50], GRAPHITE)
populate(ws, asset_rows)

wb.save(OUT)
print(f'Created {OUT} ({OUT.stat().st_size:,} bytes; {len(wb.sheetnames)} sheets)')
