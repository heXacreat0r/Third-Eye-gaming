import { readdir, readFile } from "node:fs/promises";
import path from "node:path";

// Report only locations and rule names; never print matched credential values.
const root = process.cwd();
const skip = new Set([
  "node_modules",
  ".git",
  ".pnpm-store",
  "dist",
  "artifacts",
  ".manus-logs",
]);
const patterns = [
  ["private key", /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
  ["AWS access key", /\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/],
  [
    "GitHub token",
    /\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{60,})\b/,
  ],
  ["provider key", /\b(?:sk-proj-|sk_live_|sk_test_)[A-Za-z0-9_-]{20,}\b/],
  ["credential URL", /[a-z]+:\/\/[^\s/:]+:[^\s/@]+@/i],
];
const findings = [];
const envFiles = [];
let files = 0;
async function scan(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (skip.has(entry.name) || entry.isSymbolicLink()) continue;
    const file = path.join(dir, entry.name);
    const relative = path.relative(root, file);
    if (entry.isDirectory()) {
      await scan(file);
      continue;
    }
    if (entry.name.startsWith(".env") && entry.name !== ".env.example") {
      envFiles.push(relative);
      continue;
    }
    if (
      !/\.(?:tsx?|mjs|js|json|ya?ml|html|md|sql)$/.test(entry.name) ||
      entry.name.endsWith("lock.yaml") ||
      relative === path.join("scripts", "audit-source.mjs")
    )
      continue;
    const text = await readFile(file, "utf8");
    files++;
    text.split(/\r?\n/).forEach((line, index) => {
      for (const [rule, pattern] of patterns)
        if (pattern.test(line))
          findings.push({ file: relative, line: index + 1, rule });
    });
  }
}
await scan(root);
console.log(
  JSON.stringify(
    {
      filesScanned: files,
      environmentFiles: envFiles,
      findings,
      scope:
        "Working-tree pattern scan only; no original Git history supplied.",
    },
    null,
    2
  )
);
if (findings.length) process.exitCode = 1;
