# Third Eye Gaming

Existing V2 React 19 / Vite / Express / tRPC / Drizzle storefront, restored from the owner's `Thirdeye V2.zip`. The attached Git repository was empty with no commits or remote. Product data, routes, colors, typefaces and logos are preserved. All storefront images now use the supplied local `/assets/` files.

## Run locally

Use Node 22.12+ and pnpm 10.34.9 (the pinned package manager). The available desktop runner used pnpm 11.25.0; both build-approval configuration formats are included. `.npmrc` prevents the desktop runner from replacing itself or silently reinstalling before scripts.

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Open http://localhost:3000. The public demo needs no credentials. `.env.example` documents optional service configuration without containing secrets. The scripts support Windows and POSIX shells. To test the production server:

```sh
pnpm check
pnpm test
pnpm build
pnpm start
# While the server is running:
node scripts/verify-http.mjs
node scripts/audit-source.mjs
pnpm audit
```

`pnpm dev:static` runs the frontend alone. `pnpm build:static` generates route-specific static HTML. Static hosts must separately configure API availability, response headers and 404 handling; Express security middleware does not run on a static host. Database migrations (`pnpm db:migrate` / `pnpm db:push`) change external state and were not run.

## Demo behavior

- The Heist landing-page reference informed the native editorial motion: word-by-word hero entrance, a warm atmospheric background, scroll-linked foreground keyboard-photo movement, a continuous brand ribbon that pauses on hover/focus, scroll-reveal vision headings, and a large sliding brand signoff. These use the existing Framer Motion dependency and local assets; no Heist code, assets, fonts or product claims were incorporated. The reference's foreground-release pattern was adapted without adding scroll interception or activation toggles.

- A full-width homepage vision banner places aspirational brand copy over the supplied stock keyboard photo. Scroll parallax and a slow drifting background run automatically; drift pauses offscreen, and reduced-motion preferences disable both effects. The vision copy lives in `client/src/data/homeContent.ts` and is also included in the static homepage.

- The homepage retains the setup photo, with spring-smoothed scroll zoom and perspective in the keyboard detail section. Reduced motion removes scroll animation and the long sticky section.
- The original logo gets a masked pointer spotlight and keyboard focus sweep. Reduced motion disables these effects.
- Navigation includes desktop categories, mobile links, active states, Arrow Down to open/focus the desktop menu, Escape to dismiss/restore focus, outside dismissal and route-change focus/scroll handling.
- `ProductPresentation` and `CometCard` provide automatic spring tilt, layered depth and pointer-following lighting on detail and listing cards, plus horizontal touch gestures and 44px perspective controls. The keyboard section reveals itself as you scroll, and the logo responds to pointer movement. These React/CSS effects are native to the site and have no enable switches. Device reduced-motion preferences apply automatically. The existing third-party reference frames load lazily without a load button; they remain labelled as references. Product imagery uses single-image perspective, never a fabricated product 360-degree viewer.
- The existing preview cart supports add, remove, quantity, subtotal and local persistence. Invalid saved lines are rejected, duplicate lines merged, and quantity capped at 99. Closing the dialog restores focus. Payment remains unavailable and is labelled accordingly.
- All original five categories and ten sample products remain. About, support and policy notes remain honest drafts; no new business claims or fabricated product details were added.

## Security boundaries and remaining work

Implemented: named public-environment whitelist, generic production errors, secure HttpOnly session cookies, project-bound signed sessions, minimum 32-character signing secret, provider identity consistency, server-enforced admin authorization, bounded notification inputs, same-origin API writes, request-size limits, per-process API/OAuth limits, restricted production CSP, MIME-sniffing protection, referrer and browser-permission policies, real missing-route/asset/API 404s and disabled browser/network debug collection. Production source maps are disabled. The development source-location plugin was removed because its peer range did not support the project's Vite version.

The CSP hashes the built theme bootstrap rather than allowing arbitrary inline scripts. Inline styles remain allowed for React/Framer Motion; Google Fonts and the lazy-loaded Sketchfab frame have explicit origins. The app is configured for a standalone storefront (`frame-ancestors 'self'`). Any future cross-site embedding requires an explicit, reviewed frame-origin allowlist.

The working-tree credential pattern scan is limited evidence, not a security guarantee. No original Git history or real environment files were supplied. No live database, OAuth provider, cloud account, upload endpoint, admin UI or payment integration was available for end-to-end verification. Existing database queries use Drizzle's parameterized query API; no customer/order records or ownership endpoints exist here. Storage/AI helper modules are not publicly routed. Do not expose them without separate endpoint validation and authorization.

**UNVERIFIED external actions before launch:**

1. Configure and test the OAuth provider, callback origin, a random 32+ character signing secret, and database credentials/TLS. Validate database least-privilege grants, backups and production role assignments. The unconfigured callback returns 503; the storefront still works.
2. Set `APP_ORIGIN` to the exact HTTPS public origin behind a reverse proxy. Configure HTTPS redirects and HSTS at the TLS edge, plus distributed rate limits keyed by trusted client identity. The local limiter uses the socket IP, so shared proxies share a bucket. Do not enable unrestricted `trust proxy`.
3. Confirm provider quotas, spending caps, alerting and hosting configuration in the provider consoles. No spend or payment settings were changed.
4. Replace illustrative stock photos/sample listings when finalized, supply contact details and confirm policy terms. Genuine product rotation requires a product GLB/glTF with textures or an ordered, evenly spaced photo sequence (for example, 24–36 views). No such assets were supplied.
5. Verify the retained third-party model license/attribution and availability on its original Sketchfab pages before publication. Their CC BY 4.0 metadata came from V2; automated source fetching returned 403. These generic references do not verify product form or fit.

The dependency refresh removed all reported critical, high and moderate advisories in the final audit. One **low** advisory remains in the unused starter chat renderer's transitive KaTeX dependency (GHSA-238p-pmpm-9mq7): it requires pre-existing prototype pollution and affects math trust restrictions. That renderer is not mounted by storefront routes. Upgrading it across the KaTeX minor boundary needs dedicated math-rendering compatibility checks; no clean-audit claim is made.

Interaction references were inspected for inspiration, and the effects were authored using existing Framer Motion/CSS rather than installing or copying Aceternity blocks: [keyboard scroll](https://ui.aceternity.com/components/macbook-scroll), [logo hover](https://ui.aceternity.com/components/text-hover-effect), [product perspective](https://ui.aceternity.com/components/comet-card), [navigation](https://ui.aceternity.com/blocks/navbars/navbar-mega). No paid component or additional license is required by the implementation.

## Verification record (28 October 2026)

Type checking, 12 Vitest tests, production build, 19-route static generation and peer-dependency checks passed using Node 24.14.1 / pnpm 11.25.0. The HTTP smoke script passed 19 routes, five images, five missing/debug/API routes, CSP/header checks, cross-origin rejection, oversized-body rejection and unconfigured-login behavior. The credential pattern scan found no matches in 144 text files; it did not inspect missing original Git history.

Browser checks covered the desktop at 1440px, mobile at 320px and the app's default narrow viewport: navigation, keyboard menu opening/Escape/focus, product detail, cart add/quantity/subtotal/remove, reload persistence, dialog focus return, direct static-route loading and reduced-motion behavior. No console warnings/errors appeared in the checked flows. This device requests reduced motion, so the normal-motion pointer/scroll effects still need a visual check on a device that permits animation. The reference model service, live authentication/database, Docker image and external production infrastructure were not end-to-end tested.

Vite emits an informational warning about the synchronous `/api/platform/config.js` script: it is intentionally supplied by the public-config plugin and was verified to load. The build is successful. The final frontend is split into storefront, API and motion chunks rather than one oversized entry.

No deployment, commit, credential rotation, external data change or payment/spend configuration was performed. Since Git started empty, the imported project appears as untracked files; archive-comparison artifacts under ignored `artifacts/` record the V2 changes for review.
