# Third Eye Gaming — Expanded V1 outcomes

The user expanded the former Home-only gate and requested that all five category pages, representative product details, the specified motion references, and the retailer destinations be incorporated. This checklist tracks the expanded V1 request. The provided logo remains temporary; product names/prices and third-party 3D visuals are clearly identified as preview references, not verified Third Eye Gaming products.

## Approved brand system, shared layout, and responsive behavior — Complete
- Use the approved Ink & Aperture colors: Ink `#171615`, Porcelain `#F2EEE7`, Orange `#E45C32`, Graphite `#383532`, Ash `#B9B1A7`.
- Use Space Grotesk for display text and DM Sans for body text.
- Use category colors consistently: keycaps `#E45C32`; artisan keycaps `#964633`; keycap keychains `#87572D`; mouse grips `#58665A`; mouse skates `#586467`.
- Provide light and dark modes. Follow system preference initially; retain a visitor's manual mode choice. Apply mode-appropriate logo, text, and surface colors while preserving the supplied temporary logo mark and wordmark.
- Maintain WCAG AA contrast for text and controls; use the responsive editorial grid, generous spacing, 8px rhythm, non-bubbly cards, and accessible keyboard/touch navigation.
- Use the uploaded arcade/game, Heist desktop/mobile, Land-book, Cofounder, Teka Teki and Heist references only for the specific layout/interaction cues the user requested. Do not copy another site's identity, text, illustrations, palette, or imagery.

## Home page and featured-category motion flow — In progress
- Retain the Home page with a branded hero, “Featured” (not “Best Sellers”), category navigation, product/brand highlights, and footer.
- Add a 3D/perspective motion banner on the Home page showing the featured products and categories as a coherent flow transition.
- Add the user's MacBook Scroll-style interaction to the Home page: a keyboard is visible and the keycaps are revealed/zoomed in as the visitor scrolls. Use stock illustrative media and disclose that it is not a Third Eye Gaming product.
- Use staggered hero reveal, subtle pointer parallax, scroll-triggered reveals and card hover/tilt effects. The earlier 3D tilt request is part of this outcome; fix hook ordering so Motion hooks are called unconditionally.
- Avoid a custom cursor. Respect `prefers-reduced-motion`, disable parallax for coarse pointers, and retain touch/keyboard operation.
- Keep initial content descriptive, use meaningful alt text, and lazy-load non-hero media and third-party 3D viewers.

## Five category pages and representative product detail pages — In progress
- Provide an individual page for every supplied category: Keycaps, Artisan keycaps, Keycap keychains, Mouse grips, and Mouse skates.
- The owner authorizes illustrative working product names such as `Keycap 1`, `Keycap 2`, `Artisan 1`, `Keycap Keychain 1`, `Grip Set 1`, and `Skate Set 1`; do not label any item “Best Seller.” Use “Featured” for showcase/ranking language.
- Use the owner-authorized sample product names and sample INR prices as visible preview data; identify all such names and amounts as illustrative, not finalized live prices. No materials, specifications, fitment/compatibility, guarantees, stock counts, performance claims, reviews or awards may be invented.
- Product and category images may use the already-selected stock imagery or licensed 3D reference models, but each must disclose that it is illustrative and not a Third Eye Gaming product. Keep the user's temporary logo distinct from product imagery.
- On keycap product details, include an interactive CometCard-inspired perspective/hover effect and the scroll-to-keycap detail flow.

## Mouse fit-reference and interactive 3D views — In progress
- Provide an interactive 360-degree mouse model that visitors can drag/rotate and zoom on mouse category/product pages; include a clear keyboard-accessible fallback link and lazy loading.
- Use the Logitech G PRO X SUPERLIGHT as the fit-reference model requested by the owner. The product comparison source lists `125 × 63.5 × 40 mm` for both the original PRO X SUPERLIGHT and PRO X SUPERLIGHT 2. Treat those dimensions only as a user-requested fitment reference; state that actual accessory fit must be validated against the finalized mouse revision before manufacturing.
- Attribute the public Sketchfab model `Computer mouse` by zhe_kan under CC BY 4.0; it is modeled after the Logitech G PRO X SUPERLIGHT. Attribute the public `Custom - Mechanical Keyboard` model by unknown.fbx / ibrahimtaha.fbx under CC BY 4.0. Keep creator, source page and license visible. These are reference assets, not Third Eye Gaming products.
- The sandbox's Sketchfab viewer reported a connection error during source inspection. Preserve fallback links and do not make the site dependent on third-party viewer success for meaningful page content.

## Mega navigation and logo-hover interaction — In progress
- Add a responsive mega-navigation menu inspired by the supplied Aceternity Navbar Mega reference; group links to Shop, all five categories, About and Support. Keep mobile navigation accessible and focusable.
- Add the requested Aceternity Text Hover Effect to the logo on the landing page, without obscuring the logo, preventing navigation, or making the brand name unavailable to assistive technology. Respect reduced-motion preferences.
- Apply the requested Aceternity Comet Card behavior to keycap product details. Use the references for interaction behavior, not copied styling.

## About, Support and policy copy — In progress
- Add a concise About page grounded only in the supplied facts: Third Eye Gaming is a specialist gaming peripheral accessories brand (not a whole-peripheral brand), stands for luxury/comfort in the small details, serves anyone with a mouse and keyboard, and can manufacture for other brands.
- Add a Support page with user-supplied policy facts only: shipping is intended across India; shipping costs are added at checkout; the return period is one month. Clearly mark full policy wording/conditions and the application of retailer-specific terms as pending confirmation.
- Do not invent an email address, telephone number, social account, legal entity, warranty, exact delivery time or business address. Show that contact details have not been supplied rather than fabricating them.

## Mega menu, cart, and retailer handoff — In progress
- Keep a functional cart drawer with add/remove/quantity interactions and a persistent browser-local preview cart.
- Show sample product names/prices only as illustrative preview values. Do not implement a payment method, combined checkout, first-party checkout, payment form or order confirmation.
- For each line item, provide separate retailer choices linking to the user-approved retailer homepages `https://meckeys.com/` and `https://www.genesispc.in/`. These are general retailer homepage links, not product-specific listings; say so clearly and never imply the products are available there yet.
- Leave availability, final retailer-specific price, shipping amount and transaction/policy terms to the retailer. Do not assert a completed purchase.

## SEO, route manifest, accessibility and performance — In progress
- Provide meaningful, route-specific page titles, descriptions, initial page text and social metadata for Home, Shop, each of the five categories, sample product details, About and Support. Do not invent absolute canonical or `og:url` addresses before a real public origin is configured.
- Add static route-specific prerendered HTML so meaningful page body and metadata are present before JavaScript executes. Ensure unknown/missing routes are not represented as successful product pages.
- Synchronize `client/public/manus-routes.json` with the complete implemented page route set; check its served JSON response.
- Make navigation, theme toggle, cart, image controls and viewers usable with keyboard and touch. Keep accessible names, focus states, captions, image alt text, reduced-motion support and responsive behavior.
- Keep media and 3D embeds lazy where possible, and provide graceful fallbacks when a third-party viewer fails.

## Website content workbook and asset register — In progress
- Update the separate Excel workbook to include draft headers, descriptions, CTAs and status for Home, Shop, all five category pages, representative product details, About, Support and cart.
- Include working sample product names/prices, clear sample-data flags, missing product fields, policy wording status, general retailer homepage destinations, and the model/photograph source, license, attribution and usage notes.
- Mark all copy as draft pending user review; no line is an approved brand tagline. Keep specs, materials, compatibility, SKU, contacts and final terms unfilled unless provided by the owner.
- Maintain the website asset register with stock photo provenance, source dimensions/crops, 3D model creator/license/source, use, and explicit product-placeholder distinction.

## Final validation and project checkpoint — Open
- Run the existing TypeScript diagnostic check and static production build after the expanded implementation; fix confirmed problems.
- Verify route JSON and route-specific initial HTML, inspect the Preview for the user-reported crash, and verify the page remains useful if a Sketchfab iframe fails to load.
- Keep the project static: do not enable Server, Database, payment methods, or auto-publish. Preserve the user-authorized product/business facts and all missing-input disclosures.
- Save the finished changes as a canonical Manus checkpoint on `main`; do not claim public publication unless a successful publication is explicitly confirmed.
