export default {
  logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519664047498843/nSItQSJgWDSlOVZM.png",
};
