# Third Eye Gaming — Expanded V1 implementation plan

## Scope and implementation

The user's latest request expands the earlier Home-only review gate: implement a complete responsive V1 with Home, a Shop index, one page for each of the five supplied categories, sample product detail pages, About, Support, and the existing cart drawer. Use only the supplied category names and clearly identify sample names/prices/imagery as preview data. Use “Featured,” never “Best Sellers” or sales-rank language. The user approved Superlight as the mouse reference, its standard dimensions, and general homepages for Meckeys and Genesis PC as purchase destinations. Do not create a payment flow or imply the products are currently listed at those retailers.

Retain the existing React 19, TypeScript, Vite, Wouter and Tailwind project on static Manus-managed hosting. Build a centralized `catalog.ts` for five categories and sample products; reusable page templates for category and product routes; shared mega-navigation, theme-aware logo hover, footer, cart drawer, 3D-viewer and disclosure components; and route-specific metadata. No database or application server is needed. Update `/manus-routes.json` from the implemented route set. Add a small Node/TypeScript static prerender step after Vite build to emit route-specific HTML under the static output, so crawlers see meaningful page text and metadata without waiting for client JavaScript. Do not invent canonical origins or absolute `og:url` values.

The home page will retain the approved editorial hero and add a scroll-driven keyboard-to-keycap “lens” sequence inspired by Aceternity's MacBook Scroll behavior. A horizontal/stacked featured-category flow will transition between the five categories. Use Framer Motion, already installed, for staged reveals and bounded pointer tilt; declare all hooks unconditionally, honor `prefers-reduced-motion`, and avoid a custom cursor. The logo hover effect uses text-mask/clip behavior and remains keyboard accessible with an always-visible logo.

Use two Creative Commons Attribution 4.0 Sketchfab embeds: the keyboard model “Custom - Mechanical Keyboard” by unknown.fbx / ibrahimtaha.fbx and the Superlight-shaped mouse “Computer mouse” by zhe_kan. Show creator/source/license credit next to every viewer and disclose that both are generic reference models, not Third Eye Gaming products. Keep the mouse viewer lazy-loaded and user-controlled, with 360-degree drag/zoom, reduced-motion-safe surrounding UI, keyboard-accessible fallback link, and visible reference dimensions 125 × 63.5 × 40 mm. These are the listed dimensions for both the original PRO X SUPERLIGHT and PRO X SUPERLIGHT 2 in B&H's comparison; they are only a fitment reference and must be verified against the exact hardware revision before manufacturing. The keyboard viewer and photo card are likewise illustrative until real keycap assets arrive. Since the embedded 3D viewers failed to load in the sandbox browser, present a graceful fallback link and test the real Preview; do not make the page depend on a viewer loading for its main content.

Build a purposeful visual system using the already-approved Ink & Aperture palette (`#171615`, `#F2EEE7`, `#E45C32`, `#383532`, `#B9B1A7`) and material-coded category accents (`#E45C32`, `#964633`, `#87572D`, `#58665A`, `#586467`). Display text uses Space Grotesk and body text uses DM Sans. Keep the 8px spacing system, responsive editorial grid, generous whitespace, non-bubbly cards, accessible AA contrast, and system-default light/dark themes with a remembered manual switch and appropriately recolored user-provided temporary wordmark.

Products use owner-requested working labels such as `Keycap 1`, `Keycap 2`, `Artisan 1`, `Keycap Keychain 1`, `Grip Set 1`, and `Skate Set 1`, plus sibling examples. The owner authorized sample names/prices; mark these visibly and consistently as illustrative preview data in the product catalogue, cart and copy workbook. Use INR formatting and “Featured,” never “Best Seller.” Do not invent materials, compatibility, guarantees, performance properties, inventory or reviews. State that retailer buttons open general retailer homepages, not product listings; link only to `https://meckeys.com/` and `https://www.genesispc.in/` until product-specific destinations are provided. Each item remains an independent retailer handoff; no combined checkout or first-party payment. Explain that retailer checkout controls availability, shipping charges and transaction policies. Present only user-supplied policy facts (nationwide shipping, shipping costs added at checkout, one-month returns) as draft policy summary until full terms and retailer applicability are confirmed. Do not invent a contact email or phone number; the Support page should plainly indicate that the support channel has not been supplied.

## Design

- **Design movement:** Aperture editorial — a modern, tactile product journal with precise gaming-hardware cues.
- **Core principles:** considered detail; useful comfort; honest placeholder labeling; motion with restraint.
- **Color philosophy:** warm porcelain and ink create a premium, readable canvas; the orange aperture is the ownable action color; muted category colors distinguish touchpoints without competing for attention.
- **Layout paradigm:** asymmetric editorial compositions, numbered chapter labels and a sticky scroll lens that opens from whole setup to keycap detail; category pages use a repeatable product rail rather than generic center-aligned cards.
- **Signature elements:** the supplied aperture mark; thin measurement/rule lines; coded labels such as `01 / 05` and `SETUP STUDY`.
- **Interaction philosophy:** every movement explains a product/detail or improves wayfinding. Cards respond to pointer input but remain fully usable by touch and keyboard; long-form motion is opt-out for reduced-motion preferences.
- **Animation:** quick staggered hero copy, a pinned/scroll-linked photo lens, gentle card tilt up to a few degrees, 3D model drag delegated to Sketchfab's accessible viewer controls, and short menu/cart transitions. Use low-cost transforms/opacity; stop pointer/parallax effects on coarse pointers or reduced motion.
- **Typography:** Space Grotesk at display headings (tight tracking, medium weight); DM Sans for body, prices, menus and data labels (comfortable line-height and clear contrast). Example hierarchy: very large short H1, 36–72px section H2, 16–18px explanatory text, 10–12px uppercase metadata.
- **Brand essence:** A specialist accessories brand for people who already own a mouse and keyboard; it differs through attention to design and comfort in the small details. Personality: considered, tactile, intentional.
- **Brand voice:** confident, compact and human, never gamer-cliché. Example homepage headline: “The details that make a setup yours.” Example product copy: “A considered touchpoint for the keyboard you already use.” These are draft page lines, not a brand tagline.
- **Wordmark and logo:** preserve the user-supplied temporary aperture/shuriken mark and horizontal “Third Eye Gaming” lockup, using the approved ink/orange and porcelain/orange transparent variants for the active theme.
- **Signature brand color:** Orange `#E45C32`.

## Project structure

- `client/src/App.tsx`: route table for Home, Shop, five categories, sample product detail pages, About, Support and Not Found.
- `client/src/data/homeContent.ts`: shared brand copy, categories and verified photo/model source records.
- `client/src/data/catalog.ts`: sample product records, INR display prices, links, categories, photo/3D-viewer references and preview-data flags.
- `client/src/components/brand/`: shared header/mega menu, logo hover treatment, cart, footer, product card, stock-media disclosure, and licensed 3D viewer components.
- `client/src/pages/`: Home, Shop, Category, Product, About, Support and NotFound page templates.
- `client/src/index.css`: shared theme tokens, responsive editorial layouts, 3D/perspective treatments and reduced-motion rules.
- `client/public/manus-routes.json`: exact implemented page route declaration.
- `scripts/prerender-site.ts`: static route HTML and route-specific head metadata emitted to `dist/public` after Vite build.
- `scripts/create_content_workbook.py` and `deliverables/third-eye-gaming-website-copy.xlsx`: synchronized draft copy, route/page index, sample product/price inputs, policy and retailer notes, and asset/source attribution.
- `client/public/assets/asset-register.md` and `REFERENCE-NOTES.md`: stock-photo and 3D model sources, licenses, attribution, dimensions, intended use and limitations.

## Delivery constraints

Keep stock photos, the two CC BY viewer references, and all sample product names/prices visibly distinct from verified Third Eye Gaming products. Add no login, database, payment options, newsletter capture or invented contact details. Keep the currently configured static service; do not enable Server, Database, auto-publish or public publication. After implementation, run TypeScript diagnostics and static build, inspect the route manifest and meaningful route HTML, verify the project Preview still serves without a crash, and checkpoint the work on the canonical `main` branch.
